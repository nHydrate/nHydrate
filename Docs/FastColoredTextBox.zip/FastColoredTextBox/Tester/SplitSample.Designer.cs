﻿namespace Tester
{
    partial class SplitSample
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SplitSample));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.fctbMaster = new FastColoredTextBoxNS.FastColoredTextBox();
            this.fctbSlave = new FastColoredTextBoxNS.FastColoredTextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(331, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(610, 93);
            this.label2.TabIndex = 3;
            this.label2.Text = resources.GetString("label2.Text");
            // 
            // splitter1
            // 
            this.splitter1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitter1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter1.Location = new System.Drawing.Point(0, 298);
            this.splitter1.MinSize = 0;
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(610, 6);
            this.splitter1.TabIndex = 4;
            this.splitter1.TabStop = false;
            // 
            // fctbMaster
            // 
            this.fctbMaster.AutoScrollMinSize = new System.Drawing.Size(284, 255);
            this.fctbMaster.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.fctbMaster.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fctbMaster.Language = FastColoredTextBoxNS.Language.CSharp;
            this.fctbMaster.LeftBracket = '(';
            this.fctbMaster.Location = new System.Drawing.Point(0, 93);
            this.fctbMaster.Name = "fctbMaster";
            this.fctbMaster.RightBracket = ')';
            this.fctbMaster.Size = new System.Drawing.Size(610, 205);
            this.fctbMaster.TabIndex = 0;
            this.fctbMaster.Text = resources.GetString("fctbMaster.Text");
            // 
            // fctbSlave
            // 
            this.fctbSlave.AutoScrollMinSize = new System.Drawing.Size(0, 255);
            this.fctbSlave.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.fctbSlave.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.fctbSlave.Language = FastColoredTextBoxNS.Language.CSharp;
            this.fctbSlave.LeftBracket = '(';
            this.fctbSlave.Location = new System.Drawing.Point(0, 304);
            this.fctbSlave.Name = "fctbSlave";
            this.fctbSlave.RightBracket = ')';
            this.fctbSlave.Size = new System.Drawing.Size(610, 166);
            this.fctbSlave.SourceTextBox = this.fctbMaster;
            this.fctbSlave.TabIndex = 1;
            this.fctbSlave.Text = resources.GetString("fctbSlave.Text");
            this.fctbSlave.WordWrap = true;
            // 
            // SplitSample
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(610, 470);
            this.Controls.Add(this.fctbMaster);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.fctbSlave);
            this.Name = "SplitSample";
            this.Text = "SplitSample";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private FastColoredTextBoxNS.FastColoredTextBox fctbMaster;
        private FastColoredTextBoxNS.FastColoredTextBox fctbSlave;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Splitter splitter1;
    }
}