using System;
using System.Linq;
using System.Data.Objects;
using System.Data.Objects.DataClasses;
using System.ComponentModel;
using System.Runtime.Serialization;
using System.Collections.Generic;

[assembly: EdmSchemaAttribute()]
#region EDM Relationship Metadata

[assembly: EdmRelationshipAttribute("Acme.Demo.EFDAL", "FK__Territory_Region", "Region", System.Data.Metadata.Edm.RelationshipMultiplicity.One, typeof(Acme.Demo.EFDAL.Region), "TerritoryList", System.Data.Metadata.Edm.RelationshipMultiplicity.Many, typeof(Acme.Demo.EFDAL.Territory), true)]
[assembly: EdmRelationshipAttribute("Acme.Demo.EFDAL", "EmployeeTerritory", "EmployeeList", System.Data.Metadata.Edm.RelationshipMultiplicity.Many, typeof(Acme.Demo.EFDAL.Employee), "TerritoryList", System.Data.Metadata.Edm.RelationshipMultiplicity.Many, typeof(Acme.Demo.EFDAL.Territory))]

#endregion

namespace Acme.Demo.EFDAL
{
	#region StaticDataConstants Enumeration for 'EmployeeType' entity
	/// <summary>
	/// Enumeration to define static data items and their ids 'EmployeeType' table.
	/// </summary>
	public enum EmployeeTypeConstants
	{
		/// <summary>
		/// Enumeration for the 'BigFish' item
		/// </summary>
		[Description("")]
		BigFish = 1,
		/// <summary>
		/// Enumeration for the 'Normal' item
		/// </summary>
		[Description("")]
		Normal = 2,
	}
	#endregion

	/// <summary>
	/// There are no comments for DemoEntities in the schema.
	/// </summary>
	public partial class DemoEntities : System.Data.Objects.ObjectContext
	{
		/// <summary>
		/// Initializes a new DemoEntities object using the connection string found in the 'DemoEntities' section of the application configuration file.
		/// </summary>
		public DemoEntities() :
			base("name=DemoEntities", "DemoEntities")
		{
			this.OnContextCreated();
		}

		/// <summary>
		/// Initialize a new DemoEntities object.
		/// </summary>
		public DemoEntities(string connectionString) :
			base(connectionString, "DemoEntities")
		{
			this.OnContextCreated();
		}

		/// <summary>
		/// Initialize a new DemoEntities object.
		/// </summary>
		public DemoEntities(System.Data.EntityClient.EntityConnection connection) :
			base(connection, "DemoEntities")
		{
			this.OnContextCreated();
		}

		partial void OnContextCreated();

		/// <summary>
		/// There are no comments for Customer in the schema.
		/// </summary>
		public System.Data.Objects.ObjectQuery<Customer> Customer
		{
			get { return this.SystemUser.OfType<Customer>(); }
		}

		/// <summary>
		/// There are no comments for Employee in the schema.
		/// </summary>
		public System.Data.Objects.ObjectQuery<Employee> Employee
		{
			get { return this.SystemUser.OfType<Employee>(); }
		}

		/// <summary>
		/// There are no comments for Region in the schema.
		/// </summary>
		public System.Data.Objects.ObjectSet<Region> Region
		{
			get
			{
				if ((this._region == null))
				{
					this._region = base.CreateObjectSet<Region>("Region");
				}
				return this._region;
			}
		}

		/// <summary>
		/// The internal reference variable for the 'Region' object set
		/// </summary>
		protected System.Data.Objects.ObjectSet<Region> _region;

		/// <summary>
		/// There are no comments for SystemUser in the schema.
		/// </summary>
		public System.Data.Objects.ObjectSet<SystemUser> SystemUser
		{
			get
			{
				if ((this._systemuser == null))
				{
					this._systemuser = base.CreateObjectSet<SystemUser>("SystemUser");
				}
				return this._systemuser;
			}
		}

		/// <summary>
		/// The internal reference variable for the 'SystemUser' object set
		/// </summary>
		protected System.Data.Objects.ObjectSet<SystemUser> _systemuser;

		/// <summary>
		/// There are no comments for Territory in the schema.
		/// </summary>
		public System.Data.Objects.ObjectSet<Territory> Territory
		{
			get
			{
				if ((this._territory == null))
				{
					this._territory = base.CreateObjectSet<Territory>("Territory");
				}
				return this._territory;
			}
		}

		/// <summary>
		/// The internal reference variable for the 'Territory' object set
		/// </summary>
		protected System.Data.Objects.ObjectSet<Territory> _territory;

		#region AddItem Methods

		/// <summary>
		/// Adds an object of type 'Customer' to the object context.
		/// </summary>
		/// <param name="entity">The entity to add</param>
		public void AddItem(Customer entity)
		{
			this.AddObject("SystemUser", entity);
		}

		/// <summary>
		/// Adds an object of type 'Employee' to the object context.
		/// </summary>
		/// <param name="entity">The entity to add</param>
		public void AddItem(Employee entity)
		{
			this.AddObject("SystemUser", entity);
		}

		/// <summary>
		/// Adds an object of type 'Region' to the object context.
		/// </summary>
		/// <param name="entity">The entity to add</param>
		public void AddItem(Region entity)
		{
			this.AddObject("Region", entity);
		}

		/// <summary>
		/// Adds an object of type 'SystemUser' to the object context.
		/// </summary>
		/// <param name="entity">The entity to add</param>
		public void AddItem(SystemUser entity)
		{
			this.AddObject("SystemUser", entity);
		}

		/// <summary>
		/// Adds an object of type 'Territory' to the object context.
		/// </summary>
		/// <param name="entity">The entity to add</param>
		public void AddItem(Territory entity)
		{
			this.AddObject("Territory", entity);
		}

		#endregion

	}

	/// <summary>
	/// Extension methods for this library
	/// </summary>
	public static class Extensions
	{
		/// <summary>
		/// A map for all entity types in this library
		/// </summary>
		public enum TableMappingConstants
		{
			/// <summary>
			/// A mapping for the the Customer entity
			/// </summary>
			Customer,
			/// <summary>
			/// A mapping for the the Employee entity
			/// </summary>
			Employee,
			/// <summary>
			/// A mapping for the the EmployeeType entity
			/// </summary>
			EmployeeType,
			/// <summary>
			/// A mapping for the the Region entity
			/// </summary>
			Region,
			/// <summary>
			/// A mapping for the the SystemUser entity
			/// </summary>
			SystemUser,
			/// <summary>
			/// A mapping for the the Territory entity
			/// </summary>
			Territory,
		}

		#region Include Extension Methods

		/// <summary>
		/// Specifies the related objects to include in the query results.
		/// </summary>
		/// <param name="item"></param>
		/// <param name="entity">The related entity type to include</param>
		public static ObjectQuery<Customer> Include(this ObjectQuery<Customer> item, TableMappingConstants entity)
		{
			return item.Include(GetEntityMap(entity));
		}

		/// <summary>
		/// Specifies the related objects to include in the query results.
		/// </summary>
		/// <param name="item"></param>
		/// <param name="entity">The related entity type to include</param>
		public static ObjectQuery<Employee> Include(this ObjectQuery<Employee> item, TableMappingConstants entity)
		{
			return item.Include(GetEntityMap(entity));
		}

		/// <summary>
		/// Specifies the related objects to include in the query results.
		/// </summary>
		/// <param name="item"></param>
		/// <param name="entity">The related entity type to include</param>
		public static ObjectQuery<Region> Include(this ObjectQuery<Region> item, TableMappingConstants entity)
		{
			return item.Include(GetEntityMap(entity));
		}

		/// <summary>
		/// Specifies the related objects to include in the query results.
		/// </summary>
		/// <param name="item"></param>
		/// <param name="entity">The related entity type to include</param>
		public static ObjectQuery<SystemUser> Include(this ObjectQuery<SystemUser> item, TableMappingConstants entity)
		{
			return item.Include(GetEntityMap(entity));
		}

		/// <summary>
		/// Specifies the related objects to include in the query results.
		/// </summary>
		/// <param name="item"></param>
		/// <param name="entity">The related entity type to include</param>
		public static ObjectQuery<Territory> Include(this ObjectQuery<Territory> item, TableMappingConstants entity)
		{
			return item.Include(GetEntityMap(entity));
		}

		#endregion

		private static string GetEntityMap(TableMappingConstants entity)
		{
			switch (entity)
			{
				case TableMappingConstants.Customer: return "Customer";
				case TableMappingConstants.Employee: return "Employee";
				case TableMappingConstants.EmployeeType: return "EmployeeType";
				case TableMappingConstants.Region: return "Region";
				case TableMappingConstants.SystemUser: return "SystemUser";
				case TableMappingConstants.Territory: return "Territory";
				default: throw new Exception("Unknown entity type: " + entity.ToString());
			}
		}

	}

	/// <summary>
	/// The wrapper class for the type table 'EmployeeType' used to define properties on related entities
	/// </summary>
	[EdmComplexTypeAttribute(NamespaceName="Acme.Demo.EFDAL", Name="EmployeeTypeWrapper")]
	[DataContractAttribute(IsReference=true)]
	[Serializable()]
	public partial class EmployeeTypeWrapper : ComplexObject
	{
		private EmployeeTypeConstants _status;

		/// <summary>
		/// The numeric value associated with the type
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = false)]
		[DataMemberAttribute()]
		public int Value
		{
			get { return (int)_status; }
			set { _status = (EmployeeTypeConstants)value; }
		}

		/// <summary>
		/// Serves as a hash function for a particular type.
		/// </summary>
		public override int GetHashCode()
		{
			return base.GetHashCode();
		}

		/// <summary>
		/// The enum value associated with the type
		/// </summary>
		public EmployeeTypeConstants EnumValue
		{
			get { return _status; }
			set { _status = value; }
		}

		/// <summary>
		/// Convert the enum to a wrapper object
		/// </summary>
		public static implicit operator
				EmployeeTypeWrapper(EmployeeTypeConstants status)
		{
			return new EmployeeTypeWrapper { EnumValue = status };
		}

		/// <summary>
		/// Convert a wrapper object into its associated integer value
		/// </summary>
		public static implicit operator
				int(EmployeeTypeWrapper statusWrapper)
		{
			return (int)statusWrapper.EnumValue;
		}

		/// <summary>
		/// Convert a wrapper object into its associated enum value
		/// </summary>
		public static implicit operator
				EmployeeTypeConstants(EmployeeTypeWrapper statusWrapper)
		{
			return statusWrapper.EnumValue;
		}

		/// <summary>
		/// Test two wrapper objects for equality
		/// </summary>
		public static bool operator ==(EmployeeTypeWrapper a, EmployeeTypeWrapper b)
		{
			return true;
		}

		/// <summary>
		/// Test two wrapper objects for inequality
		/// </summary>
		public static bool operator !=(EmployeeTypeWrapper a, EmployeeTypeWrapper b)
		{
			return false;
		}

		/// <summary>
		/// Compare a wrapper objects for equality against the current instance
		/// </summary>
		public override bool Equals(object obj)
		{
			//return (EmployeeTypeWrapper)obj == this;
			return true;
		}

	}

	/// <summary>
	/// The base class for all entity objects
	/// </summary>
	public abstract class NHEntityObject : EntityObject
	{
		/// <summary>
		/// Get the validation rule violations
		/// </summary>
		/// <returns></returns>
		public virtual IEnumerable<IRuleViolation> GetRuleViolations()
		{
			List<IRuleViolation> retval = new List<IRuleViolation>();
			return retval;
		}

		/// <summary>
		/// Determines if all of the validation rules have been met
		/// </summary>
		/// <returns></returns>
		public virtual bool IsValid()
		{
			return (GetRuleViolations().Count() == 0);
		}

		/// <summary>
		/// Test another entity object for equivalence against the current instance
		/// </summary>
		public abstract bool IsEquivalent(NHEntityObject item);

	}

}
