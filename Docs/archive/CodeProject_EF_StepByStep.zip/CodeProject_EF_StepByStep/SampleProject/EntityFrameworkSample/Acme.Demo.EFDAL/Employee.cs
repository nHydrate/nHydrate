namespace Acme.Demo.EFDAL
{
	partial class Employee
	{
	}
}
