using System;
using System.Linq;
using System.Runtime.Serialization;
using System.Data.Objects.DataClasses;
using System.Xml.Serialization;
using System.ComponentModel;
using System.Collections.Generic;

namespace Acme.Demo.EFDAL
{
	/// <summary>
	 /// The collection to hold 'Region' entities
	/// </summary>
	[EdmEntityTypeAttribute(NamespaceName="Acme.Demo.EFDAL", Name="Region")]
	[Serializable()]
	[DataContractAttribute(IsReference = true)]
	public partial class Region : NHEntityObject, IBusinessObject
	{
		#region FieldNameConstants Enumeration

		/// <summary>
		/// Enumeration to define each property that maps to a database field for the 'Region' table.
		/// </summary>
		public enum FieldNameConstants
		{
			 /// <summary>
			 /// Field mapping for the 'Name' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'Name' property")]
			Name,
			 /// <summary>
			 /// Field mapping for the 'RegionId' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'RegionId' property")]
			RegionId,
			 /// <summary>
			 /// Field mapping for the 'CreatedBy' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'CreatedBy' property")]
			CreatedBy,
			 /// <summary>
			 /// Field mapping for the 'CreatedDate' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'CreatedDate' property")]
			CreatedDate,
			 /// <summary>
			 /// Field mapping for the 'ModifiedBy' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'ModifiedBy' property")]
			ModifiedBy,
			 /// <summary>
			 /// Field mapping for the 'ModifiedDate' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'ModifiedDate' property")]
			ModifiedDate,
		}
		#endregion

		#region Constructors

		/// <summary>
		/// Initializes a new instance of the Acme.Demo.EFDAL.Region class
		/// </summary>
		public Region()
		{
		}

		#endregion

		#region Properties

		/// <summary>
		/// The property that maps back to the database 'name' field
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = false)]
		[DataMemberAttribute()]
		public virtual string Name
		{
			get { return _name; }
			set
			{
				if ((value != null) && (value.Length > GetMaxLength(FieldNameConstants.Name))) throw new Exception(string.Format(GlobalValues.ERROR_DATA_TOO_BIG, value, "Region.Name", GetMaxLength(FieldNameConstants.Name)));
				ChangingEventArgs<string> eventArg = new ChangingEventArgs<string>(value, "Name");
				this.OnNameChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("Name");
				_name = eventArg.Value;
				ReportPropertyChanged("Name");
				this.OnNameChanged(eventArg);
			}
		}

		/// <summary>
		/// The property that maps back to the database 'region_id' field
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = true, IsNullable = false)]
		[DataMemberAttribute()]
		public virtual int RegionId
		{
			get { return _regionid; }
			protected set
			{
				ReportPropertyChanging("RegionId");
				_regionid = value;
				ReportPropertyChanged("RegionId");
			}
		}

		/// <summary>
		/// The audit field for the 'Created By' column.
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		public virtual string CreatedBy
		{
			get { return _createdby; }
			internal set
			{
				ChangingEventArgs<string> eventArg = new ChangingEventArgs<string>(value, "CreatedBy");
				OnCreatedByChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("CreatedBy");
				_createdby = eventArg.Value;
				ReportPropertyChanged("CreatedBy");
				OnCreatedByChanged(eventArg);
			}
		}

		/// <summary>
		/// The internal reference variable for the 'createdby' property
		/// </summary>
		protected string _createdby;

		/// <summary>
		/// The audit field for the 'Created Date' column.
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		public virtual DateTime? CreatedDate
		{
			get { return _createddate; }
			internal set
			{
				ChangingEventArgs<DateTime?> eventArg = new ChangingEventArgs<DateTime?>(value, "CreatedDate");
				OnCreatedDateChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("CreatedDate");
				_createddate = eventArg.Value;
				ReportPropertyChanged("CreatedDate");
				OnCreatedDateChanged(eventArg);
			}
		}

		/// <summary>
		/// The internal reference variable for the 'createddate' property
		/// </summary>
		protected DateTime? _createddate;

		/// <summary>
		/// The audit field for the 'Modified By' column.
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		public virtual string ModifiedBy
		{
			get { return _modifiedby; }
			internal set
			{
				ChangingEventArgs<string> eventArg = new ChangingEventArgs<string>(value, "ModifiedBy");
				OnModifiedByChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("ModifiedBy");
				_modifiedby = eventArg.Value;
				ReportPropertyChanged("ModifiedBy");
				OnModifiedByChanged(eventArg);
			}
		}

		/// <summary>
		/// The internal reference variable for the 'modifiedby' property
		/// </summary>
		protected string _modifiedby;

		/// <summary>
		/// The audit field for the 'Modified Date' column.
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		public virtual DateTime? ModifiedDate
		{
			get { return _modifieddate; }
			internal set
			{
				ChangingEventArgs<DateTime?> eventArg = new ChangingEventArgs<DateTime?>(value, "ModifiedDate");
				OnModifiedDateChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("ModifiedDate");
				_modifieddate = eventArg.Value;
				ReportPropertyChanged("ModifiedDate");
				OnModifiedDateChanged(eventArg);
			}
		}

		/// <summary>
		/// The internal reference variable for the 'modifieddate' property
		/// </summary>
		protected DateTime? _modifieddate;

		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		internal virtual byte[] TimeStamp
		{
			get { return _timestamp; }
			set
			{
				ChangingEventArgs<byte[]> eventArg = new ChangingEventArgs<byte[]>(value, "TimeStamp");
				OnTimeStampChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("TimeStamp");
				_timestamp = eventArg.Value;
				ReportPropertyChanged("TimeStamp");
				OnTimeStampChanged(eventArg);
			}
		}

		/// <summary>
		/// The internal reference variable for the 'timestamp' property
		/// </summary>
		protected byte[] _timestamp;

		#endregion

		#region Events

		/// <summary>
		/// The internal reference variable for the 'Name' property
		/// </summary>
		protected string _name;

		/// <summary>
		/// Occurs when the 'Name' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<string>> NameChanging;

		/// <summary>
		/// Raises the OnNameChanging event.
		/// </summary>
		protected virtual void OnNameChanging(ChangingEventArgs<string> e)
		{
			if (this.NameChanging != null)
				this.NameChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'Name' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<string>> NameChanged;

		/// <summary>
		/// Raises the OnNameChanged event.
		/// </summary>
		protected virtual void OnNameChanged(ChangedEventArgs<string> e)
		{
			if (this.NameChanged != null)
				this.NameChanged(this, e);
		}

		/// <summary>
		/// The internal reference variable for the 'RegionId' property
		/// </summary>
		protected int _regionid;

		/// <summary>
		/// Occurs when the 'RegionId' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<int>> RegionIdChanging;

		/// <summary>
		/// Raises the OnRegionIdChanging event.
		/// </summary>
		protected virtual void OnRegionIdChanging(ChangingEventArgs<int> e)
		{
			if (this.RegionIdChanging != null)
				this.RegionIdChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'RegionId' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<int>> RegionIdChanged;

		/// <summary>
		/// Raises the OnRegionIdChanged event.
		/// </summary>
		protected virtual void OnRegionIdChanged(ChangedEventArgs<int> e)
		{
			if (this.RegionIdChanged != null)
				this.RegionIdChanged(this, e);
		}

		/// <summary>
		/// Occurs when the 'CreatedBy' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<string>> CreatedByChanging;

		/// <summary>
		/// Raises the OnCreatedByChanging event.
		/// </summary>
		protected virtual void OnCreatedByChanging(ChangingEventArgs<string> e)
		{
			if (this.CreatedByChanging != null)
				this.CreatedByChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'CreatedBy' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<string>> CreatedByChanged;

		/// <summary>
		/// Raises the OnCreatedByChanged event.
		/// </summary>
		protected virtual void OnCreatedByChanged(ChangedEventArgs<string> e)
		{
			if (this.CreatedByChanged != null)
				this.CreatedByChanged(this, e);
		}

		/// <summary>
		/// Occurs when the 'CreatedDate' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<DateTime?>> CreatedDateChanging;

		/// <summary>
		/// Raises the OnCreatedDateChanging event.
		/// </summary>
		protected virtual void OnCreatedDateChanging(ChangingEventArgs<DateTime?> e)
		{
			if (this.CreatedDateChanging != null)
				this.CreatedDateChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'CreatedDate' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<DateTime?>> CreatedDateChanged;

		/// <summary>
		/// Raises the OnCreatedDateChanged event.
		/// </summary>
		protected virtual void OnCreatedDateChanged(ChangedEventArgs<DateTime?> e)
		{
			if (this.CreatedDateChanged != null)
				this.CreatedDateChanged(this, e);
		}

		/// <summary>
		/// Occurs when the 'ModifiedBy' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<string>> ModifiedByChanging;

		/// <summary>
		/// Raises the OnModifiedByChanging event.
		/// </summary>
		protected virtual void OnModifiedByChanging(ChangingEventArgs<string> e)
		{
			if (this.ModifiedByChanging != null)
				this.ModifiedByChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'ModifiedBy' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<string>> ModifiedByChanged;

		/// <summary>
		/// Raises the OnModifiedByChanged event.
		/// </summary>
		protected virtual void OnModifiedByChanged(ChangedEventArgs<string> e)
		{
			if (this.ModifiedByChanged != null)
				this.ModifiedByChanged(this, e);
		}

		/// <summary>
		/// Occurs when the 'ModifiedDate' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<DateTime?>> ModifiedDateChanging;

		/// <summary>
		/// Raises the OnModifiedDateChanging event.
		/// </summary>
		protected virtual void OnModifiedDateChanging(ChangingEventArgs<DateTime?> e)
		{
			if (this.ModifiedDateChanging != null)
				this.ModifiedDateChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'ModifiedDate' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<DateTime?>> ModifiedDateChanged;

		/// <summary>
		/// Raises the OnModifiedDateChanged event.
		/// </summary>
		protected virtual void OnModifiedDateChanged(ChangedEventArgs<DateTime?> e)
		{
			if (this.ModifiedDateChanged != null)
				this.ModifiedDateChanged(this, e);
		}

		/// <summary>
		/// Occurs when the 'TimeStamp' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<byte[]>> TimeStampChanging;

		/// <summary>
		/// Raises the OnTimeStampChanging event.
		/// </summary>
		protected virtual void OnTimeStampChanging(ChangingEventArgs<byte[]> e)
		{
			if (this.TimeStampChanging != null)
				this.TimeStampChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'TimeStamp' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<byte[]>> TimeStampChanged;

		/// <summary>
		/// Raises the OnTimeStampChanged event.
		/// </summary>
		protected virtual void OnTimeStampChanged(ChangedEventArgs<byte[]> e)
		{
			if (this.TimeStampChanged != null)
				this.TimeStampChanged(this, e);
		}

		#endregion

		#region GetMaxLength

		/// <summary>
		/// Gets the maximum size of the field value.
		/// </summary>
		public static int GetMaxLength(FieldNameConstants field)
		{
			switch (field)
			{
				case FieldNameConstants.Name:
					return 50;
				case FieldNameConstants.RegionId:
					return 0;
			}
			return 0;
		}

		int IBusinessObject.GetMaxLength(Enum field)
		{
			return GetMaxLength((FieldNameConstants)field);
		}

		#endregion

		#region IsParented

		/// <summary>
		/// Determines if this object is part of a collection or is detached
		/// </summary>
		[System.ComponentModel.Browsable(false)]
		public virtual bool IsParented
		{
		  get { return (this.EntityState != System.Data.EntityState.Detached); }
		}

		#endregion

		#region IsEquivalent

		/// <summary>
		/// Determines if all of the fields for the specified object exactly matches the current object.
		/// </summary>
		/// <param name="item">The object to compare</param>
		public override bool IsEquivalent(NHEntityObject item)
		{
			if (item == null) return false;
			if (!(item is Region)) return false;
			Region o = item as Region;
			return (
				o.RegionId == this.RegionId &&
				o.Name == this.Name
				);
		}

		#endregion

		#region Navigation Properties

		/// <summary>
		/// The back navigation definition for walking Region->Territory
		/// </summary>
		[XmlIgnoreAttribute()]
		[SoapIgnoreAttribute()]
		[DataMemberAttribute()]
		[EdmRelationshipNavigationPropertyAttribute("Acme.Demo.EFDAL", "FK__Territory_Region", "TerritoryList")]
		public virtual EntityCollection<Territory> TerritoryList
		{
			get
			{
				//Eager load
				EntityCollection<Territory> retval = ((IEntityWithRelationships)this).RelationshipManager.GetRelatedCollection<Territory>("Acme.Demo.EFDAL.FK__Territory_Region", "TerritoryList");
				if (!_TerritoryLoad)
				{
					_TerritoryLoad = true;
					retval.Load();
				}
				return retval;
			}
			protected set
			{
				if ((value != null))
					((IEntityWithRelationships)this).RelationshipManager.InitializeRelatedCollection<Territory>("Acme.Demo.EFDAL.FK__Territory_Region", "TerritoryList", value);
			}
		}

		/// <summary>
		/// Determines if the relation to the 'Territory' entities has been walked
		/// </summary>
		protected bool _TerritoryLoad = false;

		#endregion

	}

	partial class Region : ICreatedAudit, IModifiedAudit, IConcurrencyAudit
	{
		#region ICreatedAudit Members

		string ICreatedAudit.CreatedBy
		{
			get { return this.CreatedBy; }
		}

		DateTime? ICreatedAudit.CreatedDate
		{
			get { return this.CreatedDate; }
		}

		#endregion

		#region IModifiedAudit Members

		string IModifiedAudit.ModifiedBy
		{
			get { return this.ModifiedBy; }
		}

		DateTime? IModifiedAudit.ModifiedDate
		{
			get { return this.ModifiedDate; }
		}

		#endregion

		#region IConcurrencyAudit Members

		byte[] IConcurrencyAudit.TimeStamp
		{
			get { return this.TimeStamp; }
		}

		#endregion

	}

}
