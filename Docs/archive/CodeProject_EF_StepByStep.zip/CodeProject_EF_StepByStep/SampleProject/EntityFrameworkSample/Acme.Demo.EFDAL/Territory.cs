namespace Acme.Demo.EFDAL
{
	partial class Territory
	{
	}
}
