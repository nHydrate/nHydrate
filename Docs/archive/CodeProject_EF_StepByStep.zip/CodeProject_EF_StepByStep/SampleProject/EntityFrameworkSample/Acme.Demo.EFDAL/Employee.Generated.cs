using System;
using System.Linq;
using System.Runtime.Serialization;
using System.Data.Objects.DataClasses;
using System.Xml.Serialization;
using System.ComponentModel;
using System.Collections.Generic;

namespace Acme.Demo.EFDAL
{
	/// <summary>
	 /// The collection to hold 'Employee' entities
	/// </summary>
	[EdmEntityTypeAttribute(NamespaceName="Acme.Demo.EFDAL", Name="Employee")]
	[Serializable()]
	[DataContractAttribute(IsReference = true)]
	public partial class Employee : SystemUser, IBusinessObject
	{
		#region FieldNameConstants Enumeration

		/// <summary>
		/// An enumeration of this object's image type fields
		/// </summary>
		public enum FieldImageConstants
		{
			 /// <summary>
			 /// Field mapping for the image column 'Photo' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the image column 'Photo' property")]
			Photo,
		}

		#endregion

		#region FieldNameConstants Enumeration

		/// <summary>
		/// Enumeration to define each property that maps to a database field for the 'Employee' table.
		/// </summary>
		public new enum FieldNameConstants
		{
			 /// <summary>
			 /// Field mapping for the 'Address' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'Address' property")]
			Address,
			 /// <summary>
			 /// Field mapping for the 'BirthDate' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'BirthDate' property")]
			BirthDate,
			 /// <summary>
			 /// Field mapping for the 'City' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'City' property")]
			City,
			 /// <summary>
			 /// Field mapping for the 'Country' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'Country' property")]
			Country,
			 /// <summary>
			 /// Field mapping for the 'EmployeeTypeId' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'EmployeeTypeId' property")]
			EmployeeTypeId,
			 /// <summary>
			 /// Field mapping for the 'Fax' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'Fax' property")]
			Fax,
			 /// <summary>
			 /// Field mapping for the 'FirstName' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'FirstName' property")]
			FirstName,
			 /// <summary>
			 /// Field mapping for the 'HireDate' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'HireDate' property")]
			HireDate,
			 /// <summary>
			 /// Field mapping for the 'LastName' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'LastName' property")]
			LastName,
			 /// <summary>
			 /// Field mapping for the 'MiddleName' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'MiddleName' property")]
			MiddleName,
			 /// <summary>
			 /// Field mapping for the 'Notes' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'Notes' property")]
			Notes,
			 /// <summary>
			 /// Field mapping for the 'Phone' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'Phone' property")]
			Phone,
			 /// <summary>
			 /// Field mapping for the 'PhoneExt' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'PhoneExt' property")]
			PhoneExt,
			 /// <summary>
			 /// Field mapping for the 'Photo' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'Photo' property")]
			Photo,
			 /// <summary>
			 /// Field mapping for the 'PhotoPath' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'PhotoPath' property")]
			PhotoPath,
			 /// <summary>
			 /// Field mapping for the 'PostalCode' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'PostalCode' property")]
			PostalCode,
			 /// <summary>
			 /// Field mapping for the 'Region' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'Region' property")]
			Region,
			 /// <summary>
			 /// Field mapping for the 'ReportsTo' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'ReportsTo' property")]
			ReportsTo,
			 /// <summary>
			 /// Field mapping for the 'Title' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'Title' property")]
			Title,
			 /// <summary>
			 /// Field mapping for the 'TitleOfCourtesy' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'TitleOfCourtesy' property")]
			TitleOfCourtesy,
			 /// <summary>
			 /// Field mapping for the 'UserId' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'UserId' property")]
			UserId,
			 /// <summary>
			 /// Field mapping for the 'CreatedBy' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'CreatedBy' property")]
			CreatedBy,
			 /// <summary>
			 /// Field mapping for the 'CreatedDate' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'CreatedDate' property")]
			CreatedDate,
			 /// <summary>
			 /// Field mapping for the 'ModifiedBy' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'ModifiedBy' property")]
			ModifiedBy,
			 /// <summary>
			 /// Field mapping for the 'ModifiedDate' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'ModifiedDate' property")]
			ModifiedDate,
		}
		#endregion

		#region Constructors

		/// <summary>
		/// Initializes a new instance of the Acme.Demo.EFDAL.Employee class
		/// </summary>
		public Employee()
		{
		}

		/// <summary>
		/// Initializes a new instance of the Acme.Demo.EFDAL.Employee class with a defined primary key
		/// </summary>
		public Employee(int userid)
			: this()
		{
			this.UserId = userid;
		}

		#endregion

		#region Properties

		/// <summary>
		/// The property that maps back to the database 'birth_date' field
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		public virtual DateTime? BirthDate
		{
			get { return _birthdate; }
			set
			{
				if ((value != null) && (value < GlobalValues.MIN_DATETIME)) throw new Exception("The DateTime value 'BirthDate' cannot be less than " + GlobalValues.MIN_DATETIME.ToString());
				if ((value != null) && (value > GlobalValues.MAX_DATETIME)) throw new Exception("The DateTime value 'BirthDate' cannot be greater than " + GlobalValues.MAX_DATETIME.ToString());
				ChangingEventArgs<DateTime?> eventArg = new ChangingEventArgs<DateTime?>(value, "BirthDate");
				this.OnBirthDateChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("BirthDate");
				_birthdate = eventArg.Value;
				ReportPropertyChanged("BirthDate");
				this.OnBirthDateChanged(eventArg);
			}
		}

		/// <summary>
		/// The property that maps back to the database 'employee_type_id' field
		/// </summary>
		[EdmComplexPropertyAttribute()]
		[DataMemberAttribute()]
		public virtual EmployeeTypeWrapper EmployeeType
		{
			get { return _employeetypeid; }
			set
			{
				ChangingEventArgs<EmployeeTypeConstants> eventArg = new ChangingEventArgs<EmployeeTypeConstants>(value, "EmployeeTypeId");
				this.OnEmployeeTypeChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("EmployeeTypeId");
				_employeetypeid = eventArg.Value;
				ReportPropertyChanged("EmployeeTypeId");
				this.OnEmployeeTypeChanged(eventArg);
			}
		}

		/// <summary>
		/// The property that maps back to the database 'hire_date' field
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		public virtual DateTime? HireDate
		{
			get { return _hiredate; }
			set
			{
				if ((value != null) && (value < GlobalValues.MIN_DATETIME)) throw new Exception("The DateTime value 'HireDate' cannot be less than " + GlobalValues.MIN_DATETIME.ToString());
				if ((value != null) && (value > GlobalValues.MAX_DATETIME)) throw new Exception("The DateTime value 'HireDate' cannot be greater than " + GlobalValues.MAX_DATETIME.ToString());
				ChangingEventArgs<DateTime?> eventArg = new ChangingEventArgs<DateTime?>(value, "HireDate");
				this.OnHireDateChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("HireDate");
				_hiredate = eventArg.Value;
				ReportPropertyChanged("HireDate");
				this.OnHireDateChanged(eventArg);
			}
		}

		/// <summary>
		/// The property that maps back to the database 'notes' field
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		public virtual string Notes
		{
			get { return _notes; }
			set
			{
				if ((value != null) && (value.Length > GetMaxLength(FieldNameConstants.Notes))) throw new Exception(string.Format(GlobalValues.ERROR_DATA_TOO_BIG, value, "Employee.Notes", GetMaxLength(FieldNameConstants.Notes)));
				ChangingEventArgs<string> eventArg = new ChangingEventArgs<string>(value, "Notes");
				this.OnNotesChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("Notes");
				_notes = eventArg.Value;
				ReportPropertyChanged("Notes");
				this.OnNotesChanged(eventArg);
			}
		}

		/// <summary>
		/// The property that maps back to the database 'phone_ext' field
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		public virtual string PhoneExt
		{
			get { return _phoneext; }
			set
			{
				if ((value != null) && (value.Length > GetMaxLength(FieldNameConstants.PhoneExt))) throw new Exception(string.Format(GlobalValues.ERROR_DATA_TOO_BIG, value, "Employee.PhoneExt", GetMaxLength(FieldNameConstants.PhoneExt)));
				ChangingEventArgs<string> eventArg = new ChangingEventArgs<string>(value, "PhoneExt");
				this.OnPhoneExtChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("PhoneExt");
				_phoneext = eventArg.Value;
				ReportPropertyChanged("PhoneExt");
				this.OnPhoneExtChanged(eventArg);
			}
		}

		/// <summary>
		/// The property that maps back to the database 'photo' field
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		public virtual System.Byte[] Photo
		{
			get { return _photo; }
			set
			{
				ChangingEventArgs<System.Byte[]> eventArg = new ChangingEventArgs<System.Byte[]>(value, "Photo");
				this.OnPhotoChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("Photo");
				_photo = eventArg.Value;
				ReportPropertyChanged("Photo");
				this.OnPhotoChanged(eventArg);
			}
		}

		/// <summary>
		/// The property that maps back to the database 'photo_path' field
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		public virtual string PhotoPath
		{
			get { return _photopath; }
			set
			{
				if ((value != null) && (value.Length > GetMaxLength(FieldNameConstants.PhotoPath))) throw new Exception(string.Format(GlobalValues.ERROR_DATA_TOO_BIG, value, "Employee.PhotoPath", GetMaxLength(FieldNameConstants.PhotoPath)));
				ChangingEventArgs<string> eventArg = new ChangingEventArgs<string>(value, "PhotoPath");
				this.OnPhotoPathChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("PhotoPath");
				_photopath = eventArg.Value;
				ReportPropertyChanged("PhotoPath");
				this.OnPhotoPathChanged(eventArg);
			}
		}

		/// <summary>
		/// The property that maps back to the database 'reports_to' field
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		public virtual int? ReportsTo
		{
			get { return _reportsto; }
			set
			{
				ChangingEventArgs<int?> eventArg = new ChangingEventArgs<int?>(value, "ReportsTo");
				this.OnReportsToChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("ReportsTo");
				_reportsto = eventArg.Value;
				ReportPropertyChanged("ReportsTo");
				this.OnReportsToChanged(eventArg);
			}
		}

		/// <summary>
		/// The property that maps back to the database 'title' field
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		public virtual string Title
		{
			get { return _title; }
			set
			{
				if ((value != null) && (value.Length > GetMaxLength(FieldNameConstants.Title))) throw new Exception(string.Format(GlobalValues.ERROR_DATA_TOO_BIG, value, "Employee.Title", GetMaxLength(FieldNameConstants.Title)));
				ChangingEventArgs<string> eventArg = new ChangingEventArgs<string>(value, "Title");
				this.OnTitleChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("Title");
				_title = eventArg.Value;
				ReportPropertyChanged("Title");
				this.OnTitleChanged(eventArg);
			}
		}

		/// <summary>
		/// The property that maps back to the database 'title_of_courtesy' field
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		public virtual string TitleOfCourtesy
		{
			get { return _titleofcourtesy; }
			set
			{
				if ((value != null) && (value.Length > GetMaxLength(FieldNameConstants.TitleOfCourtesy))) throw new Exception(string.Format(GlobalValues.ERROR_DATA_TOO_BIG, value, "Employee.TitleOfCourtesy", GetMaxLength(FieldNameConstants.TitleOfCourtesy)));
				ChangingEventArgs<string> eventArg = new ChangingEventArgs<string>(value, "TitleOfCourtesy");
				this.OnTitleOfCourtesyChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("TitleOfCourtesy");
				_titleofcourtesy = eventArg.Value;
				ReportPropertyChanged("TitleOfCourtesy");
				this.OnTitleOfCourtesyChanged(eventArg);
			}
		}

		#endregion

		#region Events

		/// <summary>
		/// The internal reference variable for the 'BirthDate' property
		/// </summary>
		protected DateTime? _birthdate;

		/// <summary>
		/// Occurs when the 'BirthDate' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<DateTime?>> BirthDateChanging;

		/// <summary>
		/// Raises the OnBirthDateChanging event.
		/// </summary>
		protected virtual void OnBirthDateChanging(ChangingEventArgs<DateTime?> e)
		{
			if (this.BirthDateChanging != null)
				this.BirthDateChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'BirthDate' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<DateTime?>> BirthDateChanged;

		/// <summary>
		/// Raises the OnBirthDateChanged event.
		/// </summary>
		protected virtual void OnBirthDateChanged(ChangedEventArgs<DateTime?> e)
		{
			if (this.BirthDateChanged != null)
				this.BirthDateChanged(this, e);
		}

		/// <summary>
		/// The internal reference variable for the 'EmployeeTypeId' property
		/// </summary>
		protected EmployeeTypeWrapper _employeetypeid;

		/// <summary>
		/// Occurs when the 'EmployeeType' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<EmployeeTypeConstants>> EmployeeTypeChanging;

		/// <summary>
		/// Raises the OnEmployeeTypeChanging event.
		/// </summary>
		protected virtual void OnEmployeeTypeChanging(ChangingEventArgs<EmployeeTypeConstants> e)
		{
			if (this.EmployeeTypeChanging != null)
				this.EmployeeTypeChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'EmployeeType' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<EmployeeTypeConstants>> EmployeeTypeChanged;

		/// <summary>
		/// Raises the OnEmployeeTypeChanged event.
		/// </summary>
		protected virtual void OnEmployeeTypeChanged(ChangedEventArgs<EmployeeTypeConstants> e)
		{
			if (this.EmployeeTypeChanged != null)
				this.EmployeeTypeChanged(this, e);
		}

		/// <summary>
		/// The internal reference variable for the 'HireDate' property
		/// </summary>
		protected DateTime? _hiredate;

		/// <summary>
		/// Occurs when the 'HireDate' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<DateTime?>> HireDateChanging;

		/// <summary>
		/// Raises the OnHireDateChanging event.
		/// </summary>
		protected virtual void OnHireDateChanging(ChangingEventArgs<DateTime?> e)
		{
			if (this.HireDateChanging != null)
				this.HireDateChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'HireDate' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<DateTime?>> HireDateChanged;

		/// <summary>
		/// Raises the OnHireDateChanged event.
		/// </summary>
		protected virtual void OnHireDateChanged(ChangedEventArgs<DateTime?> e)
		{
			if (this.HireDateChanged != null)
				this.HireDateChanged(this, e);
		}

		/// <summary>
		/// The internal reference variable for the 'Notes' property
		/// </summary>
		protected string _notes;

		/// <summary>
		/// Occurs when the 'Notes' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<string>> NotesChanging;

		/// <summary>
		/// Raises the OnNotesChanging event.
		/// </summary>
		protected virtual void OnNotesChanging(ChangingEventArgs<string> e)
		{
			if (this.NotesChanging != null)
				this.NotesChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'Notes' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<string>> NotesChanged;

		/// <summary>
		/// Raises the OnNotesChanged event.
		/// </summary>
		protected virtual void OnNotesChanged(ChangedEventArgs<string> e)
		{
			if (this.NotesChanged != null)
				this.NotesChanged(this, e);
		}

		/// <summary>
		/// The internal reference variable for the 'PhoneExt' property
		/// </summary>
		protected string _phoneext;

		/// <summary>
		/// Occurs when the 'PhoneExt' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<string>> PhoneExtChanging;

		/// <summary>
		/// Raises the OnPhoneExtChanging event.
		/// </summary>
		protected virtual void OnPhoneExtChanging(ChangingEventArgs<string> e)
		{
			if (this.PhoneExtChanging != null)
				this.PhoneExtChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'PhoneExt' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<string>> PhoneExtChanged;

		/// <summary>
		/// Raises the OnPhoneExtChanged event.
		/// </summary>
		protected virtual void OnPhoneExtChanged(ChangedEventArgs<string> e)
		{
			if (this.PhoneExtChanged != null)
				this.PhoneExtChanged(this, e);
		}

		/// <summary>
		/// The internal reference variable for the 'Photo' property
		/// </summary>
		protected System.Byte[] _photo;

		/// <summary>
		/// Occurs when the 'Photo' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<System.Byte[]>> PhotoChanging;

		/// <summary>
		/// Raises the OnPhotoChanging event.
		/// </summary>
		protected virtual void OnPhotoChanging(ChangingEventArgs<System.Byte[]> e)
		{
			if (this.PhotoChanging != null)
				this.PhotoChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'Photo' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<System.Byte[]>> PhotoChanged;

		/// <summary>
		/// Raises the OnPhotoChanged event.
		/// </summary>
		protected virtual void OnPhotoChanged(ChangedEventArgs<System.Byte[]> e)
		{
			if (this.PhotoChanged != null)
				this.PhotoChanged(this, e);
		}

		/// <summary>
		/// The internal reference variable for the 'PhotoPath' property
		/// </summary>
		protected string _photopath;

		/// <summary>
		/// Occurs when the 'PhotoPath' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<string>> PhotoPathChanging;

		/// <summary>
		/// Raises the OnPhotoPathChanging event.
		/// </summary>
		protected virtual void OnPhotoPathChanging(ChangingEventArgs<string> e)
		{
			if (this.PhotoPathChanging != null)
				this.PhotoPathChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'PhotoPath' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<string>> PhotoPathChanged;

		/// <summary>
		/// Raises the OnPhotoPathChanged event.
		/// </summary>
		protected virtual void OnPhotoPathChanged(ChangedEventArgs<string> e)
		{
			if (this.PhotoPathChanged != null)
				this.PhotoPathChanged(this, e);
		}

		/// <summary>
		/// The internal reference variable for the 'ReportsTo' property
		/// </summary>
		protected int? _reportsto;

		/// <summary>
		/// Occurs when the 'ReportsTo' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<int?>> ReportsToChanging;

		/// <summary>
		/// Raises the OnReportsToChanging event.
		/// </summary>
		protected virtual void OnReportsToChanging(ChangingEventArgs<int?> e)
		{
			if (this.ReportsToChanging != null)
				this.ReportsToChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'ReportsTo' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<int?>> ReportsToChanged;

		/// <summary>
		/// Raises the OnReportsToChanged event.
		/// </summary>
		protected virtual void OnReportsToChanged(ChangedEventArgs<int?> e)
		{
			if (this.ReportsToChanged != null)
				this.ReportsToChanged(this, e);
		}

		/// <summary>
		/// The internal reference variable for the 'Title' property
		/// </summary>
		protected string _title;

		/// <summary>
		/// Occurs when the 'Title' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<string>> TitleChanging;

		/// <summary>
		/// Raises the OnTitleChanging event.
		/// </summary>
		protected virtual void OnTitleChanging(ChangingEventArgs<string> e)
		{
			if (this.TitleChanging != null)
				this.TitleChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'Title' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<string>> TitleChanged;

		/// <summary>
		/// Raises the OnTitleChanged event.
		/// </summary>
		protected virtual void OnTitleChanged(ChangedEventArgs<string> e)
		{
			if (this.TitleChanged != null)
				this.TitleChanged(this, e);
		}

		/// <summary>
		/// The internal reference variable for the 'TitleOfCourtesy' property
		/// </summary>
		protected string _titleofcourtesy;

		/// <summary>
		/// Occurs when the 'TitleOfCourtesy' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<string>> TitleOfCourtesyChanging;

		/// <summary>
		/// Raises the OnTitleOfCourtesyChanging event.
		/// </summary>
		protected virtual void OnTitleOfCourtesyChanging(ChangingEventArgs<string> e)
		{
			if (this.TitleOfCourtesyChanging != null)
				this.TitleOfCourtesyChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'TitleOfCourtesy' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<string>> TitleOfCourtesyChanged;

		/// <summary>
		/// Raises the OnTitleOfCourtesyChanged event.
		/// </summary>
		protected virtual void OnTitleOfCourtesyChanged(ChangedEventArgs<string> e)
		{
			if (this.TitleOfCourtesyChanged != null)
				this.TitleOfCourtesyChanged(this, e);
		}

		#endregion

		#region GetMaxLength

		/// <summary>
		/// Gets the maximum size of the field value.
		/// </summary>
		public static int GetMaxLength(FieldNameConstants field)
		{
			switch (field)
			{
				case FieldNameConstants.Address:
					return SystemUser.GetMaxLength(SystemUser.FieldNameConstants.Address);
				case FieldNameConstants.BirthDate:
					return 0;
				case FieldNameConstants.City:
					return SystemUser.GetMaxLength(SystemUser.FieldNameConstants.City);
				case FieldNameConstants.Country:
					return SystemUser.GetMaxLength(SystemUser.FieldNameConstants.Country);
				case FieldNameConstants.EmployeeTypeId:
					return 0;
				case FieldNameConstants.Fax:
					return SystemUser.GetMaxLength(SystemUser.FieldNameConstants.Fax);
				case FieldNameConstants.FirstName:
					return SystemUser.GetMaxLength(SystemUser.FieldNameConstants.FirstName);
				case FieldNameConstants.HireDate:
					return 0;
				case FieldNameConstants.LastName:
					return SystemUser.GetMaxLength(SystemUser.FieldNameConstants.LastName);
				case FieldNameConstants.MiddleName:
					return SystemUser.GetMaxLength(SystemUser.FieldNameConstants.MiddleName);
				case FieldNameConstants.Notes:
					return int.MaxValue;
				case FieldNameConstants.Phone:
					return SystemUser.GetMaxLength(SystemUser.FieldNameConstants.Phone);
				case FieldNameConstants.PhoneExt:
					return 4;
				case FieldNameConstants.Photo:
					return int.MaxValue;
				case FieldNameConstants.PhotoPath:
					return 200;
				case FieldNameConstants.PostalCode:
					return SystemUser.GetMaxLength(SystemUser.FieldNameConstants.PostalCode);
				case FieldNameConstants.Region:
					return SystemUser.GetMaxLength(SystemUser.FieldNameConstants.Region);
				case FieldNameConstants.ReportsTo:
					return 0;
				case FieldNameConstants.Title:
					return 50;
				case FieldNameConstants.TitleOfCourtesy:
					return 50;
				case FieldNameConstants.UserId:
					return 0;
			}
			return 0;
		}

		int IBusinessObject.GetMaxLength(Enum field)
		{
			return GetMaxLength((FieldNameConstants)field);
		}

		#endregion

		#region IsParented

		/// <summary>
		/// Determines if this object is part of a collection or is detached
		/// </summary>
		[System.ComponentModel.Browsable(false)]
		public override bool IsParented
		{
		  get { return (this.EntityState != System.Data.EntityState.Detached); }
		}

		#endregion

		#region IsEquivalent

		/// <summary>
		/// Determines if all of the fields for the specified object exactly matches the current object.
		/// </summary>
		/// <param name="item">The object to compare</param>
		public override bool IsEquivalent(NHEntityObject item)
		{
			if (item == null) return false;
			if (!(item is Employee)) return false;
			Employee o = item as Employee;
			return (
				o.Region == this.Region &&
				o.PostalCode == this.PostalCode &&
				o.Phone == this.Phone &&
				o.MiddleName == this.MiddleName &&
				o.LastName == this.LastName &&
				o.FirstName == this.FirstName &&
				o.Fax == this.Fax &&
				o.Country == this.Country &&
				o.City == this.City &&
				o.Address == this.Address &&
				o.UserId == this.UserId &&
				o.TitleOfCourtesy == this.TitleOfCourtesy &&
				o.Title == this.Title &&
				o.ReportsTo == this.ReportsTo &&
				o.PhotoPath == this.PhotoPath &&
				o.Photo == this.Photo &&
				o.PhoneExt == this.PhoneExt &&
				o.Notes == this.Notes &&
				o.HireDate == this.HireDate &&
				o.EmployeeType == this.EmployeeType &&
				o.BirthDate == this.BirthDate
				);
		}

		#endregion

		#region Navigation Properties

		/// <summary>
		/// The back navigation definition for walking Employee->Territory
		/// </summary>
		[XmlIgnoreAttribute()]
		[SoapIgnoreAttribute()]
		[DataMemberAttribute()]
		[EdmRelationshipNavigationPropertyAttribute("Acme.Demo.EFDAL", "EmployeeTerritory", "TerritoryList")]
		public virtual EntityCollection<Territory> TerritoryList
		{
			get
			{
				EntityCollection<Territory> retval = ((IEntityWithRelationships)this).RelationshipManager.GetRelatedCollection<Territory>("Acme.Demo.EFDAL.EmployeeTerritory", "TerritoryList");
				if (!_TerritoryLoad)
				{
					_TerritoryLoad = true;
					retval.Load();
				}
				return retval;
			}
			protected set
			{
				if ((value != null))
					((IEntityWithRelationships)this).RelationshipManager.InitializeRelatedCollection<Territory>("Acme.Demo.EFDAL.EmployeeTerritory", "TerritoryList", value);
			}
		}

		/// <summary>
		/// Determines if the relation to the 'EmployeeTerritory' entities has been walked
		/// </summary>
		protected bool _TerritoryLoad = false;

		#endregion

	}

	partial class Employee : ICreatedAudit, IModifiedAudit, IConcurrencyAudit
	{
		#region ICreatedAudit Members

		string ICreatedAudit.CreatedBy
		{
			get { return this.CreatedBy; }
		}

		DateTime? ICreatedAudit.CreatedDate
		{
			get { return this.CreatedDate; }
		}

		#endregion

		#region IModifiedAudit Members

		string IModifiedAudit.ModifiedBy
		{
			get { return this.ModifiedBy; }
		}

		DateTime? IModifiedAudit.ModifiedDate
		{
			get { return this.ModifiedDate; }
		}

		#endregion

		#region IConcurrencyAudit Members

		byte[] IConcurrencyAudit.TimeStamp
		{
			get { return this.TimeStamp; }
		}

		#endregion

	}

}
