using System;
using System.Linq;
using System.Runtime.Serialization;
using System.Data.Objects.DataClasses;
using System.Xml.Serialization;
using System.ComponentModel;
using System.Collections.Generic;

namespace Acme.Demo.EFDAL
{
	/// <summary>
	 /// The collection to hold 'Customer' entities
	/// </summary>
	[EdmEntityTypeAttribute(NamespaceName="Acme.Demo.EFDAL", Name="Customer")]
	[Serializable()]
	[DataContractAttribute(IsReference = true)]
	public partial class Customer : SystemUser, IBusinessObject
	{
		#region FieldNameConstants Enumeration

		/// <summary>
		/// Enumeration to define each property that maps to a database field for the 'Customer' table.
		/// </summary>
		public new enum FieldNameConstants
		{
			 /// <summary>
			 /// Field mapping for the 'Address' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'Address' property")]
			Address,
			 /// <summary>
			 /// Field mapping for the 'City' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'City' property")]
			City,
			 /// <summary>
			 /// Field mapping for the 'Code' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'Code' property")]
			Code,
			 /// <summary>
			 /// Field mapping for the 'CompanyName' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'CompanyName' property")]
			CompanyName,
			 /// <summary>
			 /// Field mapping for the 'Country' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'Country' property")]
			Country,
			 /// <summary>
			 /// Field mapping for the 'Fax' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'Fax' property")]
			Fax,
			 /// <summary>
			 /// Field mapping for the 'FirstName' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'FirstName' property")]
			FirstName,
			 /// <summary>
			 /// Field mapping for the 'LastName' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'LastName' property")]
			LastName,
			 /// <summary>
			 /// Field mapping for the 'MiddleName' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'MiddleName' property")]
			MiddleName,
			 /// <summary>
			 /// Field mapping for the 'Phone' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'Phone' property")]
			Phone,
			 /// <summary>
			 /// Field mapping for the 'PostalCode' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'PostalCode' property")]
			PostalCode,
			 /// <summary>
			 /// Field mapping for the 'Region' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'Region' property")]
			Region,
			 /// <summary>
			 /// Field mapping for the 'Title' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'Title' property")]
			Title,
			 /// <summary>
			 /// Field mapping for the 'UserId' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'UserId' property")]
			UserId,
			 /// <summary>
			 /// Field mapping for the 'CreatedBy' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'CreatedBy' property")]
			CreatedBy,
			 /// <summary>
			 /// Field mapping for the 'CreatedDate' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'CreatedDate' property")]
			CreatedDate,
			 /// <summary>
			 /// Field mapping for the 'ModifiedBy' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'ModifiedBy' property")]
			ModifiedBy,
			 /// <summary>
			 /// Field mapping for the 'ModifiedDate' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'ModifiedDate' property")]
			ModifiedDate,
		}
		#endregion

		#region Constructors

		/// <summary>
		/// Initializes a new instance of the Acme.Demo.EFDAL.Customer class
		/// </summary>
		public Customer()
		{
		}

		/// <summary>
		/// Initializes a new instance of the Acme.Demo.EFDAL.Customer class with a defined primary key
		/// </summary>
		public Customer(int userid)
			: this()
		{
			this.UserId = userid;
		}

		#endregion

		#region Properties

		/// <summary>
		/// The property that maps back to the database 'code' field
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = false)]
		[DataMemberAttribute()]
		public virtual string Code
		{
			get { return _code; }
			set
			{
				if ((value != null) && (value.Length > GetMaxLength(FieldNameConstants.Code))) throw new Exception(string.Format(GlobalValues.ERROR_DATA_TOO_BIG, value, "Customer.Code", GetMaxLength(FieldNameConstants.Code)));
				ChangingEventArgs<string> eventArg = new ChangingEventArgs<string>(value, "Code");
				this.OnCodeChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("Code");
				_code = eventArg.Value;
				ReportPropertyChanged("Code");
				this.OnCodeChanged(eventArg);
			}
		}

		/// <summary>
		/// The property that maps back to the database 'company_name' field
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = false)]
		[DataMemberAttribute()]
		public virtual string CompanyName
		{
			get { return _companyname; }
			set
			{
				if ((value != null) && (value.Length > GetMaxLength(FieldNameConstants.CompanyName))) throw new Exception(string.Format(GlobalValues.ERROR_DATA_TOO_BIG, value, "Customer.CompanyName", GetMaxLength(FieldNameConstants.CompanyName)));
				ChangingEventArgs<string> eventArg = new ChangingEventArgs<string>(value, "CompanyName");
				this.OnCompanyNameChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("CompanyName");
				_companyname = eventArg.Value;
				ReportPropertyChanged("CompanyName");
				this.OnCompanyNameChanged(eventArg);
			}
		}

		/// <summary>
		/// The property that maps back to the database 'title' field
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		public virtual string Title
		{
			get { return _title; }
			set
			{
				if ((value != null) && (value.Length > GetMaxLength(FieldNameConstants.Title))) throw new Exception(string.Format(GlobalValues.ERROR_DATA_TOO_BIG, value, "Customer.Title", GetMaxLength(FieldNameConstants.Title)));
				ChangingEventArgs<string> eventArg = new ChangingEventArgs<string>(value, "Title");
				this.OnTitleChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("Title");
				_title = eventArg.Value;
				ReportPropertyChanged("Title");
				this.OnTitleChanged(eventArg);
			}
		}

		#endregion

		#region Events

		/// <summary>
		/// The internal reference variable for the 'Code' property
		/// </summary>
		protected string _code;

		/// <summary>
		/// Occurs when the 'Code' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<string>> CodeChanging;

		/// <summary>
		/// Raises the OnCodeChanging event.
		/// </summary>
		protected virtual void OnCodeChanging(ChangingEventArgs<string> e)
		{
			if (this.CodeChanging != null)
				this.CodeChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'Code' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<string>> CodeChanged;

		/// <summary>
		/// Raises the OnCodeChanged event.
		/// </summary>
		protected virtual void OnCodeChanged(ChangedEventArgs<string> e)
		{
			if (this.CodeChanged != null)
				this.CodeChanged(this, e);
		}

		/// <summary>
		/// The internal reference variable for the 'CompanyName' property
		/// </summary>
		protected string _companyname;

		/// <summary>
		/// Occurs when the 'CompanyName' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<string>> CompanyNameChanging;

		/// <summary>
		/// Raises the OnCompanyNameChanging event.
		/// </summary>
		protected virtual void OnCompanyNameChanging(ChangingEventArgs<string> e)
		{
			if (this.CompanyNameChanging != null)
				this.CompanyNameChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'CompanyName' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<string>> CompanyNameChanged;

		/// <summary>
		/// Raises the OnCompanyNameChanged event.
		/// </summary>
		protected virtual void OnCompanyNameChanged(ChangedEventArgs<string> e)
		{
			if (this.CompanyNameChanged != null)
				this.CompanyNameChanged(this, e);
		}

		/// <summary>
		/// The internal reference variable for the 'Title' property
		/// </summary>
		protected string _title;

		/// <summary>
		/// Occurs when the 'Title' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<string>> TitleChanging;

		/// <summary>
		/// Raises the OnTitleChanging event.
		/// </summary>
		protected virtual void OnTitleChanging(ChangingEventArgs<string> e)
		{
			if (this.TitleChanging != null)
				this.TitleChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'Title' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<string>> TitleChanged;

		/// <summary>
		/// Raises the OnTitleChanged event.
		/// </summary>
		protected virtual void OnTitleChanged(ChangedEventArgs<string> e)
		{
			if (this.TitleChanged != null)
				this.TitleChanged(this, e);
		}

		#endregion

		#region GetMaxLength

		/// <summary>
		/// Gets the maximum size of the field value.
		/// </summary>
		public static int GetMaxLength(FieldNameConstants field)
		{
			switch (field)
			{
				case FieldNameConstants.Address:
					return SystemUser.GetMaxLength(SystemUser.FieldNameConstants.Address);
				case FieldNameConstants.City:
					return SystemUser.GetMaxLength(SystemUser.FieldNameConstants.City);
				case FieldNameConstants.Code:
					return 10;
				case FieldNameConstants.CompanyName:
					return 50;
				case FieldNameConstants.Country:
					return SystemUser.GetMaxLength(SystemUser.FieldNameConstants.Country);
				case FieldNameConstants.Fax:
					return SystemUser.GetMaxLength(SystemUser.FieldNameConstants.Fax);
				case FieldNameConstants.FirstName:
					return SystemUser.GetMaxLength(SystemUser.FieldNameConstants.FirstName);
				case FieldNameConstants.LastName:
					return SystemUser.GetMaxLength(SystemUser.FieldNameConstants.LastName);
				case FieldNameConstants.MiddleName:
					return SystemUser.GetMaxLength(SystemUser.FieldNameConstants.MiddleName);
				case FieldNameConstants.Phone:
					return SystemUser.GetMaxLength(SystemUser.FieldNameConstants.Phone);
				case FieldNameConstants.PostalCode:
					return SystemUser.GetMaxLength(SystemUser.FieldNameConstants.PostalCode);
				case FieldNameConstants.Region:
					return SystemUser.GetMaxLength(SystemUser.FieldNameConstants.Region);
				case FieldNameConstants.Title:
					return 50;
				case FieldNameConstants.UserId:
					return 0;
			}
			return 0;
		}

		int IBusinessObject.GetMaxLength(Enum field)
		{
			return GetMaxLength((FieldNameConstants)field);
		}

		#endregion

		#region IsParented

		/// <summary>
		/// Determines if this object is part of a collection or is detached
		/// </summary>
		[System.ComponentModel.Browsable(false)]
		public override bool IsParented
		{
		  get { return (this.EntityState != System.Data.EntityState.Detached); }
		}

		#endregion

		#region IsEquivalent

		/// <summary>
		/// Determines if all of the fields for the specified object exactly matches the current object.
		/// </summary>
		/// <param name="item">The object to compare</param>
		public override bool IsEquivalent(NHEntityObject item)
		{
			if (item == null) return false;
			if (!(item is Customer)) return false;
			Customer o = item as Customer;
			return (
				o.Region == this.Region &&
				o.PostalCode == this.PostalCode &&
				o.Phone == this.Phone &&
				o.MiddleName == this.MiddleName &&
				o.LastName == this.LastName &&
				o.FirstName == this.FirstName &&
				o.Fax == this.Fax &&
				o.Country == this.Country &&
				o.City == this.City &&
				o.Address == this.Address &&
				o.UserId == this.UserId &&
				o.Title == this.Title &&
				o.CompanyName == this.CompanyName &&
				o.Code == this.Code
				);
		}

		#endregion

		#region Navigation Properties

		#endregion

	}

	partial class Customer : ICreatedAudit, IModifiedAudit, IConcurrencyAudit
	{
		#region ICreatedAudit Members

		string ICreatedAudit.CreatedBy
		{
			get { return this.CreatedBy; }
		}

		DateTime? ICreatedAudit.CreatedDate
		{
			get { return this.CreatedDate; }
		}

		#endregion

		#region IModifiedAudit Members

		string IModifiedAudit.ModifiedBy
		{
			get { return this.ModifiedBy; }
		}

		DateTime? IModifiedAudit.ModifiedDate
		{
			get { return this.ModifiedDate; }
		}

		#endregion

		#region IConcurrencyAudit Members

		byte[] IConcurrencyAudit.TimeStamp
		{
			get { return this.TimeStamp; }
		}

		#endregion

	}

}
