namespace Acme.Demo.EFDAL
{
	partial class EmployeeType
	{
	}
}
