using System;
using System.Linq;
using System.Runtime.Serialization;
using System.Data.Objects.DataClasses;
using System.Xml.Serialization;
using System.ComponentModel;
using System.Collections.Generic;

namespace Acme.Demo.EFDAL
{
	/// <summary>
	 /// The collection to hold 'SystemUser' entities
	/// </summary>
	[EdmEntityTypeAttribute(NamespaceName="Acme.Demo.EFDAL", Name="SystemUser")]
	[Serializable()]
	[DataContractAttribute(IsReference = true)]
	[KnownType(typeof(Customer))]
	[KnownType(typeof(Employee))]
	public partial class SystemUser : NHEntityObject, IBusinessObject
	{
		#region FieldNameConstants Enumeration

		/// <summary>
		/// Enumeration to define each property that maps to a database field for the 'SystemUser' table.
		/// </summary>
		public enum FieldNameConstants
		{
			 /// <summary>
			 /// Field mapping for the 'Address' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'Address' property")]
			Address,
			 /// <summary>
			 /// Field mapping for the 'City' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'City' property")]
			City,
			 /// <summary>
			 /// Field mapping for the 'Country' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'Country' property")]
			Country,
			 /// <summary>
			 /// Field mapping for the 'Fax' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'Fax' property")]
			Fax,
			 /// <summary>
			 /// Field mapping for the 'FirstName' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'FirstName' property")]
			FirstName,
			 /// <summary>
			 /// Field mapping for the 'LastName' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'LastName' property")]
			LastName,
			 /// <summary>
			 /// Field mapping for the 'MiddleName' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'MiddleName' property")]
			MiddleName,
			 /// <summary>
			 /// Field mapping for the 'Phone' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'Phone' property")]
			Phone,
			 /// <summary>
			 /// Field mapping for the 'PostalCode' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'PostalCode' property")]
			PostalCode,
			 /// <summary>
			 /// Field mapping for the 'Region' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'Region' property")]
			Region,
			 /// <summary>
			 /// Field mapping for the 'UserId' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'UserId' property")]
			UserId,
			 /// <summary>
			 /// Field mapping for the 'CreatedBy' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'CreatedBy' property")]
			CreatedBy,
			 /// <summary>
			 /// Field mapping for the 'CreatedDate' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'CreatedDate' property")]
			CreatedDate,
			 /// <summary>
			 /// Field mapping for the 'ModifiedBy' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'ModifiedBy' property")]
			ModifiedBy,
			 /// <summary>
			 /// Field mapping for the 'ModifiedDate' property
			 /// </summary>
			[System.ComponentModel.Description("Field mapping for the 'ModifiedDate' property")]
			ModifiedDate,
		}
		#endregion

		#region Constructors

		/// <summary>
		/// Initializes a new instance of the Acme.Demo.EFDAL.SystemUser class
		/// </summary>
		public SystemUser()
		{
		}

		#endregion

		#region Properties

		/// <summary>
		/// The property that maps back to the database 'address' field
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		public virtual string Address
		{
			get { return _address; }
			set
			{
				if ((value != null) && (value.Length > GetMaxLength(FieldNameConstants.Address))) throw new Exception(string.Format(GlobalValues.ERROR_DATA_TOO_BIG, value, "SystemUser.Address", GetMaxLength(FieldNameConstants.Address)));
				ChangingEventArgs<string> eventArg = new ChangingEventArgs<string>(value, "Address");
				this.OnAddressChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("Address");
				_address = eventArg.Value;
				ReportPropertyChanged("Address");
				this.OnAddressChanged(eventArg);
			}
		}

		/// <summary>
		/// The property that maps back to the database 'city' field
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		public virtual string City
		{
			get { return _city; }
			set
			{
				if ((value != null) && (value.Length > GetMaxLength(FieldNameConstants.City))) throw new Exception(string.Format(GlobalValues.ERROR_DATA_TOO_BIG, value, "SystemUser.City", GetMaxLength(FieldNameConstants.City)));
				ChangingEventArgs<string> eventArg = new ChangingEventArgs<string>(value, "City");
				this.OnCityChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("City");
				_city = eventArg.Value;
				ReportPropertyChanged("City");
				this.OnCityChanged(eventArg);
			}
		}

		/// <summary>
		/// The property that maps back to the database 'country' field
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		public virtual string Country
		{
			get { return _country; }
			set
			{
				if ((value != null) && (value.Length > GetMaxLength(FieldNameConstants.Country))) throw new Exception(string.Format(GlobalValues.ERROR_DATA_TOO_BIG, value, "SystemUser.Country", GetMaxLength(FieldNameConstants.Country)));
				ChangingEventArgs<string> eventArg = new ChangingEventArgs<string>(value, "Country");
				this.OnCountryChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("Country");
				_country = eventArg.Value;
				ReportPropertyChanged("Country");
				this.OnCountryChanged(eventArg);
			}
		}

		/// <summary>
		/// The property that maps back to the database 'fax' field
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		public virtual string Fax
		{
			get { return _fax; }
			set
			{
				if ((value != null) && (value.Length > GetMaxLength(FieldNameConstants.Fax))) throw new Exception(string.Format(GlobalValues.ERROR_DATA_TOO_BIG, value, "SystemUser.Fax", GetMaxLength(FieldNameConstants.Fax)));
				ChangingEventArgs<string> eventArg = new ChangingEventArgs<string>(value, "Fax");
				this.OnFaxChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("Fax");
				_fax = eventArg.Value;
				ReportPropertyChanged("Fax");
				this.OnFaxChanged(eventArg);
			}
		}

		/// <summary>
		/// The property that maps back to the database 'first_name' field
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = false)]
		[DataMemberAttribute()]
		public virtual string FirstName
		{
			get { return _firstname; }
			set
			{
				if ((value != null) && (value.Length > GetMaxLength(FieldNameConstants.FirstName))) throw new Exception(string.Format(GlobalValues.ERROR_DATA_TOO_BIG, value, "SystemUser.FirstName", GetMaxLength(FieldNameConstants.FirstName)));
				ChangingEventArgs<string> eventArg = new ChangingEventArgs<string>(value, "FirstName");
				this.OnFirstNameChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("FirstName");
				_firstname = eventArg.Value;
				ReportPropertyChanged("FirstName");
				this.OnFirstNameChanged(eventArg);
			}
		}

		/// <summary>
		/// The property that maps back to the database 'last_name' field
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = false)]
		[DataMemberAttribute()]
		public virtual string LastName
		{
			get { return _lastname; }
			set
			{
				if ((value != null) && (value.Length > GetMaxLength(FieldNameConstants.LastName))) throw new Exception(string.Format(GlobalValues.ERROR_DATA_TOO_BIG, value, "SystemUser.LastName", GetMaxLength(FieldNameConstants.LastName)));
				ChangingEventArgs<string> eventArg = new ChangingEventArgs<string>(value, "LastName");
				this.OnLastNameChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("LastName");
				_lastname = eventArg.Value;
				ReportPropertyChanged("LastName");
				this.OnLastNameChanged(eventArg);
			}
		}

		/// <summary>
		/// The property that maps back to the database 'middle_name' field
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		public virtual string MiddleName
		{
			get { return _middlename; }
			set
			{
				if ((value != null) && (value.Length > GetMaxLength(FieldNameConstants.MiddleName))) throw new Exception(string.Format(GlobalValues.ERROR_DATA_TOO_BIG, value, "SystemUser.MiddleName", GetMaxLength(FieldNameConstants.MiddleName)));
				ChangingEventArgs<string> eventArg = new ChangingEventArgs<string>(value, "MiddleName");
				this.OnMiddleNameChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("MiddleName");
				_middlename = eventArg.Value;
				ReportPropertyChanged("MiddleName");
				this.OnMiddleNameChanged(eventArg);
			}
		}

		/// <summary>
		/// The property that maps back to the database 'phone' field
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		public virtual string Phone
		{
			get { return _phone; }
			set
			{
				if ((value != null) && (value.Length > GetMaxLength(FieldNameConstants.Phone))) throw new Exception(string.Format(GlobalValues.ERROR_DATA_TOO_BIG, value, "SystemUser.Phone", GetMaxLength(FieldNameConstants.Phone)));
				ChangingEventArgs<string> eventArg = new ChangingEventArgs<string>(value, "Phone");
				this.OnPhoneChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("Phone");
				_phone = eventArg.Value;
				ReportPropertyChanged("Phone");
				this.OnPhoneChanged(eventArg);
			}
		}

		/// <summary>
		/// The property that maps back to the database 'postal_code' field
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		public virtual string PostalCode
		{
			get { return _postalcode; }
			set
			{
				if ((value != null) && (value.Length > GetMaxLength(FieldNameConstants.PostalCode))) throw new Exception(string.Format(GlobalValues.ERROR_DATA_TOO_BIG, value, "SystemUser.PostalCode", GetMaxLength(FieldNameConstants.PostalCode)));
				ChangingEventArgs<string> eventArg = new ChangingEventArgs<string>(value, "PostalCode");
				this.OnPostalCodeChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("PostalCode");
				_postalcode = eventArg.Value;
				ReportPropertyChanged("PostalCode");
				this.OnPostalCodeChanged(eventArg);
			}
		}

		/// <summary>
		/// The property that maps back to the database 'region' field
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		public virtual string Region
		{
			get { return _region; }
			set
			{
				if ((value != null) && (value.Length > GetMaxLength(FieldNameConstants.Region))) throw new Exception(string.Format(GlobalValues.ERROR_DATA_TOO_BIG, value, "SystemUser.Region", GetMaxLength(FieldNameConstants.Region)));
				ChangingEventArgs<string> eventArg = new ChangingEventArgs<string>(value, "Region");
				this.OnRegionChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("Region");
				_region = eventArg.Value;
				ReportPropertyChanged("Region");
				this.OnRegionChanged(eventArg);
			}
		}

		/// <summary>
		/// The property that maps back to the database 'user_id' field
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = true, IsNullable = false)]
		[DataMemberAttribute()]
		public virtual int UserId
		{
			get { return _userid; }
			protected set
			{
				ReportPropertyChanging("UserId");
				_userid = value;
				ReportPropertyChanged("UserId");
			}
		}

		/// <summary>
		/// The audit field for the 'Created By' column.
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		public virtual string CreatedBy
		{
			get { return _createdby; }
			internal set
			{
				ChangingEventArgs<string> eventArg = new ChangingEventArgs<string>(value, "CreatedBy");
				OnCreatedByChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("CreatedBy");
				_createdby = eventArg.Value;
				ReportPropertyChanged("CreatedBy");
				OnCreatedByChanged(eventArg);
			}
		}

		/// <summary>
		/// The internal reference variable for the 'createdby' property
		/// </summary>
		protected string _createdby;

		/// <summary>
		/// The audit field for the 'Created Date' column.
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		public virtual DateTime? CreatedDate
		{
			get { return _createddate; }
			internal set
			{
				ChangingEventArgs<DateTime?> eventArg = new ChangingEventArgs<DateTime?>(value, "CreatedDate");
				OnCreatedDateChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("CreatedDate");
				_createddate = eventArg.Value;
				ReportPropertyChanged("CreatedDate");
				OnCreatedDateChanged(eventArg);
			}
		}

		/// <summary>
		/// The internal reference variable for the 'createddate' property
		/// </summary>
		protected DateTime? _createddate;

		/// <summary>
		/// The audit field for the 'Modified By' column.
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		public virtual string ModifiedBy
		{
			get { return _modifiedby; }
			internal set
			{
				ChangingEventArgs<string> eventArg = new ChangingEventArgs<string>(value, "ModifiedBy");
				OnModifiedByChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("ModifiedBy");
				_modifiedby = eventArg.Value;
				ReportPropertyChanged("ModifiedBy");
				OnModifiedByChanged(eventArg);
			}
		}

		/// <summary>
		/// The internal reference variable for the 'modifiedby' property
		/// </summary>
		protected string _modifiedby;

		/// <summary>
		/// The audit field for the 'Modified Date' column.
		/// </summary>
		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		public virtual DateTime? ModifiedDate
		{
			get { return _modifieddate; }
			internal set
			{
				ChangingEventArgs<DateTime?> eventArg = new ChangingEventArgs<DateTime?>(value, "ModifiedDate");
				OnModifiedDateChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("ModifiedDate");
				_modifieddate = eventArg.Value;
				ReportPropertyChanged("ModifiedDate");
				OnModifiedDateChanged(eventArg);
			}
		}

		/// <summary>
		/// The internal reference variable for the 'modifieddate' property
		/// </summary>
		protected DateTime? _modifieddate;

		[EdmScalarPropertyAttribute(EntityKeyProperty = false, IsNullable = true)]
		[DataMemberAttribute()]
		internal virtual byte[] TimeStamp
		{
			get { return _timestamp; }
			set
			{
				ChangingEventArgs<byte[]> eventArg = new ChangingEventArgs<byte[]>(value, "TimeStamp");
				OnTimeStampChanging(eventArg);
				if (eventArg.Cancel) return;
				ReportPropertyChanging("TimeStamp");
				_timestamp = eventArg.Value;
				ReportPropertyChanged("TimeStamp");
				OnTimeStampChanged(eventArg);
			}
		}

		/// <summary>
		/// The internal reference variable for the 'timestamp' property
		/// </summary>
		protected byte[] _timestamp;

		#endregion

		#region Events

		/// <summary>
		/// The internal reference variable for the 'Address' property
		/// </summary>
		protected string _address;

		/// <summary>
		/// Occurs when the 'Address' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<string>> AddressChanging;

		/// <summary>
		/// Raises the OnAddressChanging event.
		/// </summary>
		protected virtual void OnAddressChanging(ChangingEventArgs<string> e)
		{
			if (this.AddressChanging != null)
				this.AddressChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'Address' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<string>> AddressChanged;

		/// <summary>
		/// Raises the OnAddressChanged event.
		/// </summary>
		protected virtual void OnAddressChanged(ChangedEventArgs<string> e)
		{
			if (this.AddressChanged != null)
				this.AddressChanged(this, e);
		}

		/// <summary>
		/// The internal reference variable for the 'City' property
		/// </summary>
		protected string _city;

		/// <summary>
		/// Occurs when the 'City' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<string>> CityChanging;

		/// <summary>
		/// Raises the OnCityChanging event.
		/// </summary>
		protected virtual void OnCityChanging(ChangingEventArgs<string> e)
		{
			if (this.CityChanging != null)
				this.CityChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'City' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<string>> CityChanged;

		/// <summary>
		/// Raises the OnCityChanged event.
		/// </summary>
		protected virtual void OnCityChanged(ChangedEventArgs<string> e)
		{
			if (this.CityChanged != null)
				this.CityChanged(this, e);
		}

		/// <summary>
		/// The internal reference variable for the 'Country' property
		/// </summary>
		protected string _country;

		/// <summary>
		/// Occurs when the 'Country' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<string>> CountryChanging;

		/// <summary>
		/// Raises the OnCountryChanging event.
		/// </summary>
		protected virtual void OnCountryChanging(ChangingEventArgs<string> e)
		{
			if (this.CountryChanging != null)
				this.CountryChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'Country' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<string>> CountryChanged;

		/// <summary>
		/// Raises the OnCountryChanged event.
		/// </summary>
		protected virtual void OnCountryChanged(ChangedEventArgs<string> e)
		{
			if (this.CountryChanged != null)
				this.CountryChanged(this, e);
		}

		/// <summary>
		/// The internal reference variable for the 'Fax' property
		/// </summary>
		protected string _fax;

		/// <summary>
		/// Occurs when the 'Fax' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<string>> FaxChanging;

		/// <summary>
		/// Raises the OnFaxChanging event.
		/// </summary>
		protected virtual void OnFaxChanging(ChangingEventArgs<string> e)
		{
			if (this.FaxChanging != null)
				this.FaxChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'Fax' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<string>> FaxChanged;

		/// <summary>
		/// Raises the OnFaxChanged event.
		/// </summary>
		protected virtual void OnFaxChanged(ChangedEventArgs<string> e)
		{
			if (this.FaxChanged != null)
				this.FaxChanged(this, e);
		}

		/// <summary>
		/// The internal reference variable for the 'FirstName' property
		/// </summary>
		protected string _firstname;

		/// <summary>
		/// Occurs when the 'FirstName' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<string>> FirstNameChanging;

		/// <summary>
		/// Raises the OnFirstNameChanging event.
		/// </summary>
		protected virtual void OnFirstNameChanging(ChangingEventArgs<string> e)
		{
			if (this.FirstNameChanging != null)
				this.FirstNameChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'FirstName' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<string>> FirstNameChanged;

		/// <summary>
		/// Raises the OnFirstNameChanged event.
		/// </summary>
		protected virtual void OnFirstNameChanged(ChangedEventArgs<string> e)
		{
			if (this.FirstNameChanged != null)
				this.FirstNameChanged(this, e);
		}

		/// <summary>
		/// The internal reference variable for the 'LastName' property
		/// </summary>
		protected string _lastname;

		/// <summary>
		/// Occurs when the 'LastName' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<string>> LastNameChanging;

		/// <summary>
		/// Raises the OnLastNameChanging event.
		/// </summary>
		protected virtual void OnLastNameChanging(ChangingEventArgs<string> e)
		{
			if (this.LastNameChanging != null)
				this.LastNameChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'LastName' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<string>> LastNameChanged;

		/// <summary>
		/// Raises the OnLastNameChanged event.
		/// </summary>
		protected virtual void OnLastNameChanged(ChangedEventArgs<string> e)
		{
			if (this.LastNameChanged != null)
				this.LastNameChanged(this, e);
		}

		/// <summary>
		/// The internal reference variable for the 'MiddleName' property
		/// </summary>
		protected string _middlename;

		/// <summary>
		/// Occurs when the 'MiddleName' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<string>> MiddleNameChanging;

		/// <summary>
		/// Raises the OnMiddleNameChanging event.
		/// </summary>
		protected virtual void OnMiddleNameChanging(ChangingEventArgs<string> e)
		{
			if (this.MiddleNameChanging != null)
				this.MiddleNameChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'MiddleName' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<string>> MiddleNameChanged;

		/// <summary>
		/// Raises the OnMiddleNameChanged event.
		/// </summary>
		protected virtual void OnMiddleNameChanged(ChangedEventArgs<string> e)
		{
			if (this.MiddleNameChanged != null)
				this.MiddleNameChanged(this, e);
		}

		/// <summary>
		/// The internal reference variable for the 'Phone' property
		/// </summary>
		protected string _phone;

		/// <summary>
		/// Occurs when the 'Phone' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<string>> PhoneChanging;

		/// <summary>
		/// Raises the OnPhoneChanging event.
		/// </summary>
		protected virtual void OnPhoneChanging(ChangingEventArgs<string> e)
		{
			if (this.PhoneChanging != null)
				this.PhoneChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'Phone' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<string>> PhoneChanged;

		/// <summary>
		/// Raises the OnPhoneChanged event.
		/// </summary>
		protected virtual void OnPhoneChanged(ChangedEventArgs<string> e)
		{
			if (this.PhoneChanged != null)
				this.PhoneChanged(this, e);
		}

		/// <summary>
		/// The internal reference variable for the 'PostalCode' property
		/// </summary>
		protected string _postalcode;

		/// <summary>
		/// Occurs when the 'PostalCode' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<string>> PostalCodeChanging;

		/// <summary>
		/// Raises the OnPostalCodeChanging event.
		/// </summary>
		protected virtual void OnPostalCodeChanging(ChangingEventArgs<string> e)
		{
			if (this.PostalCodeChanging != null)
				this.PostalCodeChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'PostalCode' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<string>> PostalCodeChanged;

		/// <summary>
		/// Raises the OnPostalCodeChanged event.
		/// </summary>
		protected virtual void OnPostalCodeChanged(ChangedEventArgs<string> e)
		{
			if (this.PostalCodeChanged != null)
				this.PostalCodeChanged(this, e);
		}

		/// <summary>
		/// The internal reference variable for the 'Region' property
		/// </summary>
		protected string _region;

		/// <summary>
		/// Occurs when the 'Region' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<string>> RegionChanging;

		/// <summary>
		/// Raises the OnRegionChanging event.
		/// </summary>
		protected virtual void OnRegionChanging(ChangingEventArgs<string> e)
		{
			if (this.RegionChanging != null)
				this.RegionChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'Region' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<string>> RegionChanged;

		/// <summary>
		/// Raises the OnRegionChanged event.
		/// </summary>
		protected virtual void OnRegionChanged(ChangedEventArgs<string> e)
		{
			if (this.RegionChanged != null)
				this.RegionChanged(this, e);
		}

		/// <summary>
		/// The internal reference variable for the 'UserId' property
		/// </summary>
		protected int _userid;

		/// <summary>
		/// Occurs when the 'UserId' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<int>> UserIdChanging;

		/// <summary>
		/// Raises the OnUserIdChanging event.
		/// </summary>
		protected virtual void OnUserIdChanging(ChangingEventArgs<int> e)
		{
			if (this.UserIdChanging != null)
				this.UserIdChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'UserId' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<int>> UserIdChanged;

		/// <summary>
		/// Raises the OnUserIdChanged event.
		/// </summary>
		protected virtual void OnUserIdChanged(ChangedEventArgs<int> e)
		{
			if (this.UserIdChanged != null)
				this.UserIdChanged(this, e);
		}

		/// <summary>
		/// Occurs when the 'CreatedBy' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<string>> CreatedByChanging;

		/// <summary>
		/// Raises the OnCreatedByChanging event.
		/// </summary>
		protected virtual void OnCreatedByChanging(ChangingEventArgs<string> e)
		{
			if (this.CreatedByChanging != null)
				this.CreatedByChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'CreatedBy' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<string>> CreatedByChanged;

		/// <summary>
		/// Raises the OnCreatedByChanged event.
		/// </summary>
		protected virtual void OnCreatedByChanged(ChangedEventArgs<string> e)
		{
			if (this.CreatedByChanged != null)
				this.CreatedByChanged(this, e);
		}

		/// <summary>
		/// Occurs when the 'CreatedDate' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<DateTime?>> CreatedDateChanging;

		/// <summary>
		/// Raises the OnCreatedDateChanging event.
		/// </summary>
		protected virtual void OnCreatedDateChanging(ChangingEventArgs<DateTime?> e)
		{
			if (this.CreatedDateChanging != null)
				this.CreatedDateChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'CreatedDate' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<DateTime?>> CreatedDateChanged;

		/// <summary>
		/// Raises the OnCreatedDateChanged event.
		/// </summary>
		protected virtual void OnCreatedDateChanged(ChangedEventArgs<DateTime?> e)
		{
			if (this.CreatedDateChanged != null)
				this.CreatedDateChanged(this, e);
		}

		/// <summary>
		/// Occurs when the 'ModifiedBy' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<string>> ModifiedByChanging;

		/// <summary>
		/// Raises the OnModifiedByChanging event.
		/// </summary>
		protected virtual void OnModifiedByChanging(ChangingEventArgs<string> e)
		{
			if (this.ModifiedByChanging != null)
				this.ModifiedByChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'ModifiedBy' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<string>> ModifiedByChanged;

		/// <summary>
		/// Raises the OnModifiedByChanged event.
		/// </summary>
		protected virtual void OnModifiedByChanged(ChangedEventArgs<string> e)
		{
			if (this.ModifiedByChanged != null)
				this.ModifiedByChanged(this, e);
		}

		/// <summary>
		/// Occurs when the 'ModifiedDate' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<DateTime?>> ModifiedDateChanging;

		/// <summary>
		/// Raises the OnModifiedDateChanging event.
		/// </summary>
		protected virtual void OnModifiedDateChanging(ChangingEventArgs<DateTime?> e)
		{
			if (this.ModifiedDateChanging != null)
				this.ModifiedDateChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'ModifiedDate' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<DateTime?>> ModifiedDateChanged;

		/// <summary>
		/// Raises the OnModifiedDateChanged event.
		/// </summary>
		protected virtual void OnModifiedDateChanged(ChangedEventArgs<DateTime?> e)
		{
			if (this.ModifiedDateChanged != null)
				this.ModifiedDateChanged(this, e);
		}

		/// <summary>
		/// Occurs when the 'TimeStamp' property value change is a pending.
		/// </summary>
		public event EventHandler<ChangingEventArgs<byte[]>> TimeStampChanging;

		/// <summary>
		/// Raises the OnTimeStampChanging event.
		/// </summary>
		protected virtual void OnTimeStampChanging(ChangingEventArgs<byte[]> e)
		{
			if (this.TimeStampChanging != null)
				this.TimeStampChanging(this, e);
		}

		/// <summary>
		/// Occurs when the 'TimeStamp' property value has changed.
		/// </summary>
		public event EventHandler<ChangedEventArgs<byte[]>> TimeStampChanged;

		/// <summary>
		/// Raises the OnTimeStampChanged event.
		/// </summary>
		protected virtual void OnTimeStampChanged(ChangedEventArgs<byte[]> e)
		{
			if (this.TimeStampChanged != null)
				this.TimeStampChanged(this, e);
		}

		#endregion

		#region GetMaxLength

		/// <summary>
		/// Gets the maximum size of the field value.
		/// </summary>
		public static int GetMaxLength(FieldNameConstants field)
		{
			switch (field)
			{
				case FieldNameConstants.Address:
					return 50;
				case FieldNameConstants.City:
					return 50;
				case FieldNameConstants.Country:
					return 50;
				case FieldNameConstants.Fax:
					return 50;
				case FieldNameConstants.FirstName:
					return 50;
				case FieldNameConstants.LastName:
					return 50;
				case FieldNameConstants.MiddleName:
					return 50;
				case FieldNameConstants.Phone:
					return 50;
				case FieldNameConstants.PostalCode:
					return 50;
				case FieldNameConstants.Region:
					return 50;
				case FieldNameConstants.UserId:
					return 0;
			}
			return 0;
		}

		int IBusinessObject.GetMaxLength(Enum field)
		{
			return GetMaxLength((FieldNameConstants)field);
		}

		#endregion

		#region IsParented

		/// <summary>
		/// Determines if this object is part of a collection or is detached
		/// </summary>
		[System.ComponentModel.Browsable(false)]
		public virtual bool IsParented
		{
		  get { return (this.EntityState != System.Data.EntityState.Detached); }
		}

		#endregion

		#region IsEquivalent

		/// <summary>
		/// Determines if all of the fields for the specified object exactly matches the current object.
		/// </summary>
		/// <param name="item">The object to compare</param>
		public override bool IsEquivalent(NHEntityObject item)
		{
			if (item == null) return false;
			if (!(item is SystemUser)) return false;
			SystemUser o = item as SystemUser;
			return (
				o.UserId == this.UserId &&
				o.Region == this.Region &&
				o.PostalCode == this.PostalCode &&
				o.Phone == this.Phone &&
				o.MiddleName == this.MiddleName &&
				o.LastName == this.LastName &&
				o.FirstName == this.FirstName &&
				o.Fax == this.Fax &&
				o.Country == this.Country &&
				o.City == this.City &&
				o.Address == this.Address
				);
		}

		#endregion

		#region Navigation Properties

		#endregion

	}

	partial class SystemUser : ICreatedAudit, IModifiedAudit, IConcurrencyAudit
	{
		#region ICreatedAudit Members

		string ICreatedAudit.CreatedBy
		{
			get { return this.CreatedBy; }
		}

		DateTime? ICreatedAudit.CreatedDate
		{
			get { return this.CreatedDate; }
		}

		#endregion

		#region IModifiedAudit Members

		string IModifiedAudit.ModifiedBy
		{
			get { return this.ModifiedBy; }
		}

		DateTime? IModifiedAudit.ModifiedDate
		{
			get { return this.ModifiedDate; }
		}

		#endregion

		#region IConcurrencyAudit Members

		byte[] IConcurrencyAudit.TimeStamp
		{
			get { return this.TimeStamp; }
		}

		#endregion

	}

}
