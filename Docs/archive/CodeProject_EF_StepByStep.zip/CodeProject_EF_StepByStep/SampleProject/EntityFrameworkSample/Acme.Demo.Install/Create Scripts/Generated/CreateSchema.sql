--DO NOT MODIFY THIS FILE. IT IS ALWAYS OVERWRITTEN ON GENERATION.
--Data Schema For Version 0.0.0.0
--Generated on 2010-07-12 22:33:36

--CREATE TABLE [CUSTOMER]
if not exists(select * from sysobjects where name = 'CUSTOMER' and xtype = 'U')
CREATE TABLE [dbo].[CUSTOMER] (
[code] [VarChar] (10) NOT NULL ,
[company_name] [VarChar] (50) NOT NULL ,
[title] [VarChar] (50) NULL ,
[user_id] [Int] NOT NULL ,
[modified_by] [Varchar] (50) NULL ,
[modified_date] [DateTime] CONSTRAINT [DF__CUSTOMER_MODIFIED_DATE] DEFAULT GetDate() NULL ,
[created_by] [Varchar] (50) NULL ,
[created_date] [DateTime] CONSTRAINT [DF__CUSTOMER_CREATED_DATE] DEFAULT GetDate() NULL ,
[time_stamp] [timestamp] NOT NULL 
) ON [PRIMARY]


GO

--CREATE TABLE [EMPLOYEE]
if not exists(select * from sysobjects where name = 'EMPLOYEE' and xtype = 'U')
CREATE TABLE [dbo].[EMPLOYEE] (
[birth_date] [DateTime] NULL ,
[employee_type_id] [Int] NULL ,
[hire_date] [DateTime] NULL ,
[notes] [Text] NULL ,
[phone_ext] [VarChar] (4) NULL ,
[photo] [Image] NULL ,
[photo_path] [VarChar] (200) NULL ,
[reports_to] [Int] NULL ,
[title] [VarChar] (50) NULL ,
[title_of_courtesy] [VarChar] (50) NULL ,
[user_id] [Int] NOT NULL ,
[modified_by] [Varchar] (50) NULL ,
[modified_date] [DateTime] CONSTRAINT [DF__EMPLOYEE_MODIFIED_DATE] DEFAULT GetDate() NULL ,
[created_by] [Varchar] (50) NULL ,
[created_date] [DateTime] CONSTRAINT [DF__EMPLOYEE_CREATED_DATE] DEFAULT GetDate() NULL ,
[time_stamp] [timestamp] NOT NULL 
) ON [PRIMARY]


GO

--CREATE TABLE [EMPLOYEE_TERRITORY]
if not exists(select * from sysobjects where name = 'EMPLOYEE_TERRITORY' and xtype = 'U')
CREATE TABLE [dbo].[EMPLOYEE_TERRITORY] (
[territory_id] [VarChar] (20) NOT NULL ,
[user_id] [Int] NOT NULL ,
[modified_by] [Varchar] (50) NULL ,
[modified_date] [DateTime] CONSTRAINT [DF__EMPLOYEE_TERRITORY_MODIFIED_DATE] DEFAULT GetDate() NULL ,
[created_by] [Varchar] (50) NULL ,
[created_date] [DateTime] CONSTRAINT [DF__EMPLOYEE_TERRITORY_CREATED_DATE] DEFAULT GetDate() NULL ,
[time_stamp] [timestamp] NOT NULL 
) ON [PRIMARY]


GO

--CREATE TABLE [EMPLOYEE_TYPE]
if not exists(select * from sysobjects where name = 'EMPLOYEE_TYPE' and xtype = 'U')
CREATE TABLE [dbo].[EMPLOYEE_TYPE] (
[employee_type_id] [Int] IDENTITY (1, 1) NOT NULL ,
[name] [VarChar] (100) NOT NULL ,
[modified_by] [Varchar] (50) NULL ,
[modified_date] [DateTime] CONSTRAINT [DF__EMPLOYEE_TYPE_MODIFIED_DATE] DEFAULT GetDate() NULL ,
[created_by] [Varchar] (50) NULL ,
[created_date] [DateTime] CONSTRAINT [DF__EMPLOYEE_TYPE_CREATED_DATE] DEFAULT GetDate() NULL ,
[time_stamp] [timestamp] NOT NULL 
) ON [PRIMARY]


GO

--CREATE TABLE [REGION]
if not exists(select * from sysobjects where name = 'REGION' and xtype = 'U')
CREATE TABLE [dbo].[REGION] (
[name] [VarChar] (50) NOT NULL ,
[region_id] [Int] IDENTITY (1, 1) NOT NULL ,
[modified_by] [Varchar] (50) NULL ,
[modified_date] [DateTime] CONSTRAINT [DF__REGION_MODIFIED_DATE] DEFAULT GetDate() NULL ,
[created_by] [Varchar] (50) NULL ,
[created_date] [DateTime] CONSTRAINT [DF__REGION_CREATED_DATE] DEFAULT GetDate() NULL ,
[time_stamp] [timestamp] NOT NULL 
) ON [PRIMARY]


GO

--CREATE TABLE [SYSTEM_USER]
if not exists(select * from sysobjects where name = 'SYSTEM_USER' and xtype = 'U')
CREATE TABLE [dbo].[SYSTEM_USER] (
[address] [VarChar] (50) NULL ,
[city] [VarChar] (50) NULL ,
[country] [VarChar] (50) NULL ,
[fax] [VarChar] (50) NULL ,
[first_name] [VarChar] (50) NOT NULL ,
[last_name] [VarChar] (50) NOT NULL ,
[middle_name] [VarChar] (50) NULL ,
[phone] [VarChar] (50) NULL ,
[postal_code] [VarChar] (50) NULL ,
[region] [VarChar] (50) NULL ,
[user_id] [Int] IDENTITY (1, 1) NOT NULL ,
[modified_by] [Varchar] (50) NULL ,
[modified_date] [DateTime] CONSTRAINT [DF__SYSTEM_USER_MODIFIED_DATE] DEFAULT GetDate() NULL ,
[created_by] [Varchar] (50) NULL ,
[created_date] [DateTime] CONSTRAINT [DF__SYSTEM_USER_CREATED_DATE] DEFAULT GetDate() NULL ,
[time_stamp] [timestamp] NOT NULL 
) ON [PRIMARY]


GO

--CREATE TABLE [TERRITORY]
if not exists(select * from sysobjects where name = 'TERRITORY' and xtype = 'U')
CREATE TABLE [dbo].[TERRITORY] (
[name] [VarChar] (50) NOT NULL ,
[region_id] [Int] NOT NULL ,
[territory_id] [VarChar] (20) NOT NULL ,
[modified_by] [Varchar] (50) NULL ,
[modified_date] [DateTime] CONSTRAINT [DF__TERRITORY_MODIFIED_DATE] DEFAULT GetDate() NULL ,
[created_by] [Varchar] (50) NULL ,
[created_date] [DateTime] CONSTRAINT [DF__TERRITORY_CREATED_DATE] DEFAULT GetDate() NULL ,
[time_stamp] [timestamp] NOT NULL 
) ON [PRIMARY]


GO

--APPEND AUDIT TRAIL CREATE for Table [CUSTOMER]
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'created_by' and o.name = 'CUSTOMER')
ALTER TABLE [dbo].[CUSTOMER] ADD [created_by] [Varchar] (50) NULL
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'created_date' and o.name = 'CUSTOMER')
ALTER TABLE [dbo].[CUSTOMER] ADD [created_date] [DateTime] CONSTRAINT [DF__CUSTOMER_CREATED_DATE] DEFAULT GetDate() NULL

--APPEND AUDIT TRAIL MODIFY for Table [CUSTOMER]
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'modified_by' and o.name = 'CUSTOMER')
ALTER TABLE [dbo].[CUSTOMER] ADD [modified_by] [Varchar] (50) NULL
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'modified_date' and o.name = 'CUSTOMER')
ALTER TABLE [dbo].[CUSTOMER] ADD [modified_date] [DateTime] CONSTRAINT [DF__CUSTOMER_MODIFIED_DATE] DEFAULT GetDate() NULL

--APPEND AUDIT TRAIL TIMESTAMP for Table [CUSTOMER]
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'time_stamp' and o.name = 'CUSTOMER')
ALTER TABLE [dbo].[CUSTOMER] ADD [time_stamp] [timestamp] NOT NULL

--APPEND AUDIT TRAIL CREATE for Table [EMPLOYEE]
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'created_by' and o.name = 'EMPLOYEE')
ALTER TABLE [dbo].[EMPLOYEE] ADD [created_by] [Varchar] (50) NULL
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'created_date' and o.name = 'EMPLOYEE')
ALTER TABLE [dbo].[EMPLOYEE] ADD [created_date] [DateTime] CONSTRAINT [DF__EMPLOYEE_CREATED_DATE] DEFAULT GetDate() NULL

--APPEND AUDIT TRAIL MODIFY for Table [EMPLOYEE]
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'modified_by' and o.name = 'EMPLOYEE')
ALTER TABLE [dbo].[EMPLOYEE] ADD [modified_by] [Varchar] (50) NULL
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'modified_date' and o.name = 'EMPLOYEE')
ALTER TABLE [dbo].[EMPLOYEE] ADD [modified_date] [DateTime] CONSTRAINT [DF__EMPLOYEE_MODIFIED_DATE] DEFAULT GetDate() NULL

--APPEND AUDIT TRAIL TIMESTAMP for Table [EMPLOYEE]
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'time_stamp' and o.name = 'EMPLOYEE')
ALTER TABLE [dbo].[EMPLOYEE] ADD [time_stamp] [timestamp] NOT NULL

--APPEND AUDIT TRAIL CREATE for Table [EMPLOYEE_TERRITORY]
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'created_by' and o.name = 'EMPLOYEE_TERRITORY')
ALTER TABLE [dbo].[EMPLOYEE_TERRITORY] ADD [created_by] [Varchar] (50) NULL
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'created_date' and o.name = 'EMPLOYEE_TERRITORY')
ALTER TABLE [dbo].[EMPLOYEE_TERRITORY] ADD [created_date] [DateTime] CONSTRAINT [DF__EMPLOYEE_TERRITORY_CREATED_DATE] DEFAULT GetDate() NULL

--APPEND AUDIT TRAIL MODIFY for Table [EMPLOYEE_TERRITORY]
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'modified_by' and o.name = 'EMPLOYEE_TERRITORY')
ALTER TABLE [dbo].[EMPLOYEE_TERRITORY] ADD [modified_by] [Varchar] (50) NULL
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'modified_date' and o.name = 'EMPLOYEE_TERRITORY')
ALTER TABLE [dbo].[EMPLOYEE_TERRITORY] ADD [modified_date] [DateTime] CONSTRAINT [DF__EMPLOYEE_TERRITORY_MODIFIED_DATE] DEFAULT GetDate() NULL

--APPEND AUDIT TRAIL TIMESTAMP for Table [EMPLOYEE_TERRITORY]
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'time_stamp' and o.name = 'EMPLOYEE_TERRITORY')
ALTER TABLE [dbo].[EMPLOYEE_TERRITORY] ADD [time_stamp] [timestamp] NOT NULL

--APPEND AUDIT TRAIL CREATE for Table [EMPLOYEE_TYPE]
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'created_by' and o.name = 'EMPLOYEE_TYPE')
ALTER TABLE [dbo].[EMPLOYEE_TYPE] ADD [created_by] [Varchar] (50) NULL
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'created_date' and o.name = 'EMPLOYEE_TYPE')
ALTER TABLE [dbo].[EMPLOYEE_TYPE] ADD [created_date] [DateTime] CONSTRAINT [DF__EMPLOYEE_TYPE_CREATED_DATE] DEFAULT GetDate() NULL

--APPEND AUDIT TRAIL MODIFY for Table [EMPLOYEE_TYPE]
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'modified_by' and o.name = 'EMPLOYEE_TYPE')
ALTER TABLE [dbo].[EMPLOYEE_TYPE] ADD [modified_by] [Varchar] (50) NULL
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'modified_date' and o.name = 'EMPLOYEE_TYPE')
ALTER TABLE [dbo].[EMPLOYEE_TYPE] ADD [modified_date] [DateTime] CONSTRAINT [DF__EMPLOYEE_TYPE_MODIFIED_DATE] DEFAULT GetDate() NULL

--APPEND AUDIT TRAIL TIMESTAMP for Table [EMPLOYEE_TYPE]
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'time_stamp' and o.name = 'EMPLOYEE_TYPE')
ALTER TABLE [dbo].[EMPLOYEE_TYPE] ADD [time_stamp] [timestamp] NOT NULL

--APPEND AUDIT TRAIL CREATE for Table [REGION]
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'created_by' and o.name = 'REGION')
ALTER TABLE [dbo].[REGION] ADD [created_by] [Varchar] (50) NULL
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'created_date' and o.name = 'REGION')
ALTER TABLE [dbo].[REGION] ADD [created_date] [DateTime] CONSTRAINT [DF__REGION_CREATED_DATE] DEFAULT GetDate() NULL

--APPEND AUDIT TRAIL MODIFY for Table [REGION]
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'modified_by' and o.name = 'REGION')
ALTER TABLE [dbo].[REGION] ADD [modified_by] [Varchar] (50) NULL
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'modified_date' and o.name = 'REGION')
ALTER TABLE [dbo].[REGION] ADD [modified_date] [DateTime] CONSTRAINT [DF__REGION_MODIFIED_DATE] DEFAULT GetDate() NULL

--APPEND AUDIT TRAIL TIMESTAMP for Table [REGION]
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'time_stamp' and o.name = 'REGION')
ALTER TABLE [dbo].[REGION] ADD [time_stamp] [timestamp] NOT NULL

--APPEND AUDIT TRAIL CREATE for Table [SYSTEM_USER]
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'created_by' and o.name = 'SYSTEM_USER')
ALTER TABLE [dbo].[SYSTEM_USER] ADD [created_by] [Varchar] (50) NULL
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'created_date' and o.name = 'SYSTEM_USER')
ALTER TABLE [dbo].[SYSTEM_USER] ADD [created_date] [DateTime] CONSTRAINT [DF__SYSTEM_USER_CREATED_DATE] DEFAULT GetDate() NULL

--APPEND AUDIT TRAIL MODIFY for Table [SYSTEM_USER]
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'modified_by' and o.name = 'SYSTEM_USER')
ALTER TABLE [dbo].[SYSTEM_USER] ADD [modified_by] [Varchar] (50) NULL
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'modified_date' and o.name = 'SYSTEM_USER')
ALTER TABLE [dbo].[SYSTEM_USER] ADD [modified_date] [DateTime] CONSTRAINT [DF__SYSTEM_USER_MODIFIED_DATE] DEFAULT GetDate() NULL

--APPEND AUDIT TRAIL TIMESTAMP for Table [SYSTEM_USER]
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'time_stamp' and o.name = 'SYSTEM_USER')
ALTER TABLE [dbo].[SYSTEM_USER] ADD [time_stamp] [timestamp] NOT NULL

--APPEND AUDIT TRAIL CREATE for Table [TERRITORY]
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'created_by' and o.name = 'TERRITORY')
ALTER TABLE [dbo].[TERRITORY] ADD [created_by] [Varchar] (50) NULL
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'created_date' and o.name = 'TERRITORY')
ALTER TABLE [dbo].[TERRITORY] ADD [created_date] [DateTime] CONSTRAINT [DF__TERRITORY_CREATED_DATE] DEFAULT GetDate() NULL

--APPEND AUDIT TRAIL MODIFY for Table [TERRITORY]
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'modified_by' and o.name = 'TERRITORY')
ALTER TABLE [dbo].[TERRITORY] ADD [modified_by] [Varchar] (50) NULL
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'modified_date' and o.name = 'TERRITORY')
ALTER TABLE [dbo].[TERRITORY] ADD [modified_date] [DateTime] CONSTRAINT [DF__TERRITORY_MODIFIED_DATE] DEFAULT GetDate() NULL

--APPEND AUDIT TRAIL TIMESTAMP for Table [TERRITORY]
if not exists (select * from syscolumns c inner join sysobjects o on c.id = o.id where c.name = 'time_stamp' and o.name = 'TERRITORY')
ALTER TABLE [dbo].[TERRITORY] ADD [time_stamp] [timestamp] NOT NULL

--PRIMARY KEY FOR TABLE [CUSTOMER]
if not exists(select * from sysobjects where name = 'PK_CUSTOMER' and xtype = 'PK')
ALTER TABLE [dbo].[CUSTOMER] WITH NOCHECK ADD 
CONSTRAINT [PK_CUSTOMER] PRIMARY KEY CLUSTERED 
(
	[user_id]
) ON [PRIMARY] 
GO

--PRIMARY KEY FOR TABLE [EMPLOYEE]
if not exists(select * from sysobjects where name = 'PK_EMPLOYEE' and xtype = 'PK')
ALTER TABLE [dbo].[EMPLOYEE] WITH NOCHECK ADD 
CONSTRAINT [PK_EMPLOYEE] PRIMARY KEY CLUSTERED 
(
	[user_id]
) ON [PRIMARY] 
GO

--PRIMARY KEY FOR TABLE [EMPLOYEE_TERRITORY]
if not exists(select * from sysobjects where name = 'PK_EMPLOYEE_TERRITORY' and xtype = 'PK')
ALTER TABLE [dbo].[EMPLOYEE_TERRITORY] WITH NOCHECK ADD 
CONSTRAINT [PK_EMPLOYEE_TERRITORY] PRIMARY KEY CLUSTERED 
(
	[territory_id],
	[user_id]
) ON [PRIMARY] 
GO

--PRIMARY KEY FOR TABLE [EMPLOYEE_TYPE]
if not exists(select * from sysobjects where name = 'PK_EMPLOYEE_TYPE' and xtype = 'PK')
ALTER TABLE [dbo].[EMPLOYEE_TYPE] WITH NOCHECK ADD 
CONSTRAINT [PK_EMPLOYEE_TYPE] PRIMARY KEY CLUSTERED 
(
	[employee_type_id]
) ON [PRIMARY] 
GO

--PRIMARY KEY FOR TABLE [REGION]
if not exists(select * from sysobjects where name = 'PK_REGION' and xtype = 'PK')
ALTER TABLE [dbo].[REGION] WITH NOCHECK ADD 
CONSTRAINT [PK_REGION] PRIMARY KEY CLUSTERED 
(
	[region_id]
) ON [PRIMARY] 
GO

--PRIMARY KEY FOR TABLE [SYSTEM_USER]
if not exists(select * from sysobjects where name = 'PK_SYSTEM_USER' and xtype = 'PK')
ALTER TABLE [dbo].[SYSTEM_USER] WITH NOCHECK ADD 
CONSTRAINT [PK_SYSTEM_USER] PRIMARY KEY CLUSTERED 
(
	[user_id]
) ON [PRIMARY] 
GO

--PRIMARY KEY FOR TABLE [TERRITORY]
if not exists(select * from sysobjects where name = 'PK_TERRITORY' and xtype = 'PK')
ALTER TABLE [dbo].[TERRITORY] WITH NOCHECK ADD 
CONSTRAINT [PK_TERRITORY] PRIMARY KEY CLUSTERED 
(
	[territory_id]
) ON [PRIMARY] 
GO

--FOREIGN KEY RELATIONSHIP [SYSTEM_USER] -> [CUSTOMER] ([SYSTEM_USER].[user_id] -> [CUSTOMER].[user_id])
if not exists(select * from sysobjects where name = 'FK__CUSTOMER_SYSTEM_USER' and xtype = 'F')
ALTER TABLE [dbo].[CUSTOMER] ADD 
CONSTRAINT [FK__CUSTOMER_SYSTEM_USER] FOREIGN KEY 
(
		[user_id]
) REFERENCES [dbo].[SYSTEM_USER] (
		[user_id]
)
GO


--FOREIGN KEY RELATIONSHIP [EMPLOYEE_TYPE] -> [EMPLOYEE] ([EMPLOYEE_TYPE].[employee_type_id] -> [EMPLOYEE].[employee_type_id])
if not exists(select * from sysobjects where name = 'FK__EMPLOYEE_EMPLOYEE_TYPE' and xtype = 'F')
ALTER TABLE [dbo].[EMPLOYEE] ADD 
CONSTRAINT [FK__EMPLOYEE_EMPLOYEE_TYPE] FOREIGN KEY 
(
		[employee_type_id]
) REFERENCES [dbo].[EMPLOYEE_TYPE] (
		[employee_type_id]
)
GO

--FOREIGN KEY RELATIONSHIP [SYSTEM_USER] -> [EMPLOYEE] ([SYSTEM_USER].[user_id] -> [EMPLOYEE].[user_id])
if not exists(select * from sysobjects where name = 'FK__EMPLOYEE_SYSTEM_USER' and xtype = 'F')
ALTER TABLE [dbo].[EMPLOYEE] ADD 
CONSTRAINT [FK__EMPLOYEE_SYSTEM_USER] FOREIGN KEY 
(
		[user_id]
) REFERENCES [dbo].[SYSTEM_USER] (
		[user_id]
)
GO


--FOREIGN KEY RELATIONSHIP [EMPLOYEE] -> [EMPLOYEE_TERRITORY] ([EMPLOYEE].[user_id] -> [EMPLOYEE_TERRITORY].[user_id])
if not exists(select * from sysobjects where name = 'FK__EMPLOYEE_TERRITORY_EMPLOYEE' and xtype = 'F')
ALTER TABLE [dbo].[EMPLOYEE_TERRITORY] ADD 
CONSTRAINT [FK__EMPLOYEE_TERRITORY_EMPLOYEE] FOREIGN KEY 
(
		[user_id]
) REFERENCES [dbo].[EMPLOYEE] (
		[user_id]
)
GO

--FOREIGN KEY RELATIONSHIP [TERRITORY] -> [EMPLOYEE_TERRITORY] ([TERRITORY].[territory_id] -> [EMPLOYEE_TERRITORY].[territory_id])
if not exists(select * from sysobjects where name = 'FK__EMPLOYEE_TERRITORY_TERRITORY' and xtype = 'F')
ALTER TABLE [dbo].[EMPLOYEE_TERRITORY] ADD 
CONSTRAINT [FK__EMPLOYEE_TERRITORY_TERRITORY] FOREIGN KEY 
(
		[territory_id]
) REFERENCES [dbo].[TERRITORY] (
		[territory_id]
)
GO


--FOREIGN KEY RELATIONSHIP [REGION] -> [TERRITORY] ([REGION].[region_id] -> [TERRITORY].[region_id])
if not exists(select * from sysobjects where name = 'FK__TERRITORY_REGION' and xtype = 'F')
ALTER TABLE [dbo].[TERRITORY] ADD 
CONSTRAINT [FK__TERRITORY_REGION] FOREIGN KEY 
(
		[region_id]
) REFERENCES [dbo].[REGION] (
		[region_id]
)
GO


--DROP ANY AUDIT TRIGGERS FOR [CUSTOMER]
if exists(select * from sysobjects where name = '__TR_CUSTOMER__INSERT' AND xtype = 'TR')
DROP TRIGGER [__TR_CUSTOMER__INSERT]
GO
if exists(select * from sysobjects where name = '__TR_CUSTOMER__UPDATE' AND xtype = 'TR')
DROP TRIGGER [__TR_CUSTOMER__UPDATE]
GO
if exists(select * from sysobjects where name = '__TR_CUSTOMER__DELETE' AND xtype = 'TR')
DROP TRIGGER [__TR_CUSTOMER__DELETE]
GO

--DROP ANY AUDIT TRIGGERS FOR [EMPLOYEE]
if exists(select * from sysobjects where name = '__TR_EMPLOYEE__INSERT' AND xtype = 'TR')
DROP TRIGGER [__TR_EMPLOYEE__INSERT]
GO
if exists(select * from sysobjects where name = '__TR_EMPLOYEE__UPDATE' AND xtype = 'TR')
DROP TRIGGER [__TR_EMPLOYEE__UPDATE]
GO
if exists(select * from sysobjects where name = '__TR_EMPLOYEE__DELETE' AND xtype = 'TR')
DROP TRIGGER [__TR_EMPLOYEE__DELETE]
GO

--DROP ANY AUDIT TRIGGERS FOR [EMPLOYEE_TERRITORY]
if exists(select * from sysobjects where name = '__TR_EMPLOYEE_TERRITORY__INSERT' AND xtype = 'TR')
DROP TRIGGER [__TR_EMPLOYEE_TERRITORY__INSERT]
GO
if exists(select * from sysobjects where name = '__TR_EMPLOYEE_TERRITORY__UPDATE' AND xtype = 'TR')
DROP TRIGGER [__TR_EMPLOYEE_TERRITORY__UPDATE]
GO
if exists(select * from sysobjects where name = '__TR_EMPLOYEE_TERRITORY__DELETE' AND xtype = 'TR')
DROP TRIGGER [__TR_EMPLOYEE_TERRITORY__DELETE]
GO

--DROP ANY AUDIT TRIGGERS FOR [EMPLOYEE_TYPE]
if exists(select * from sysobjects where name = '__TR_EMPLOYEE_TYPE__INSERT' AND xtype = 'TR')
DROP TRIGGER [__TR_EMPLOYEE_TYPE__INSERT]
GO
if exists(select * from sysobjects where name = '__TR_EMPLOYEE_TYPE__UPDATE' AND xtype = 'TR')
DROP TRIGGER [__TR_EMPLOYEE_TYPE__UPDATE]
GO
if exists(select * from sysobjects where name = '__TR_EMPLOYEE_TYPE__DELETE' AND xtype = 'TR')
DROP TRIGGER [__TR_EMPLOYEE_TYPE__DELETE]
GO

--DROP ANY AUDIT TRIGGERS FOR [REGION]
if exists(select * from sysobjects where name = '__TR_REGION__INSERT' AND xtype = 'TR')
DROP TRIGGER [__TR_REGION__INSERT]
GO
if exists(select * from sysobjects where name = '__TR_REGION__UPDATE' AND xtype = 'TR')
DROP TRIGGER [__TR_REGION__UPDATE]
GO
if exists(select * from sysobjects where name = '__TR_REGION__DELETE' AND xtype = 'TR')
DROP TRIGGER [__TR_REGION__DELETE]
GO

--DROP ANY AUDIT TRIGGERS FOR [SYSTEM_USER]
if exists(select * from sysobjects where name = '__TR_SYSTEM_USER__INSERT' AND xtype = 'TR')
DROP TRIGGER [__TR_SYSTEM_USER__INSERT]
GO
if exists(select * from sysobjects where name = '__TR_SYSTEM_USER__UPDATE' AND xtype = 'TR')
DROP TRIGGER [__TR_SYSTEM_USER__UPDATE]
GO
if exists(select * from sysobjects where name = '__TR_SYSTEM_USER__DELETE' AND xtype = 'TR')
DROP TRIGGER [__TR_SYSTEM_USER__DELETE]
GO

--DROP ANY AUDIT TRIGGERS FOR [TERRITORY]
if exists(select * from sysobjects where name = '__TR_TERRITORY__INSERT' AND xtype = 'TR')
DROP TRIGGER [__TR_TERRITORY__INSERT]
GO
if exists(select * from sysobjects where name = '__TR_TERRITORY__UPDATE' AND xtype = 'TR')
DROP TRIGGER [__TR_TERRITORY__UPDATE]
GO
if exists(select * from sysobjects where name = '__TR_TERRITORY__DELETE' AND xtype = 'TR')
DROP TRIGGER [__TR_TERRITORY__DELETE]
GO

