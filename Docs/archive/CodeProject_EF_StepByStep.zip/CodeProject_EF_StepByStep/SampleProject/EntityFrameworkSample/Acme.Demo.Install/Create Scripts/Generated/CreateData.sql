--DO NOT MODIFY THIS FILE. IT IS ALWAYS OVERWRITTEN ON GENERATION.
--Static Data For Version 0.0.0.0
--Generated on 2010-07-12 22:33:36

exec sp_MSforeachtable 'ALTER TABLE ? NOCHECK CONSTRAINT ALL'

--INSERT STATIC DATA FOR TABLE [EMPLOYEE_TYPE]
SET identity_insert [dbo].[EMPLOYEE_TYPE] on
if not exists(select * from [dbo].[EMPLOYEE_TYPE] where ([employee_type_id] = 1)) INSERT INTO [dbo].[EMPLOYEE_TYPE] ([employee_type_id],[name]) values (1,'BigFish')
if not exists(select * from [dbo].[EMPLOYEE_TYPE] where ([employee_type_id] = 2)) INSERT INTO [dbo].[EMPLOYEE_TYPE] ([employee_type_id],[name]) values (2,'Normal')
SET identity_insert [dbo].[EMPLOYEE_TYPE] off

exec sp_MSforeachtable 'ALTER TABLE ? CHECK CONSTRAINT ALL'

