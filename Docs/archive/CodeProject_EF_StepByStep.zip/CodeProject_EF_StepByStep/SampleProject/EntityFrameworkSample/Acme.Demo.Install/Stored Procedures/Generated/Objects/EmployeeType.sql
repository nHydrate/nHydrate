--DO NOT MODIFY THIS FILE. IT IS ALWAYS OVERWRITTEN ON GENERATION.
--Model Version 0.0.0.0

--This SQL is generated for the table 'EMPLOYEE_TYPE'


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[gen_EmployeeTypeDelete]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	drop procedure [dbo].[gen_EmployeeTypeDelete]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE [dbo].[gen_EmployeeTypeDelete]
(
	@Original_employee_type_id [Int]
)
AS
SET NOCOUNT OFF;

DELETE FROM 
	[EMPLOYEE_TYPE] 
WHERE 
	[employee_type_id] = @Original_employee_type_id ;

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[gen_EmployeeTypeSelectByEmployeeTypePks]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	drop procedure [dbo].[gen_EmployeeTypeSelectByEmployeeTypePks]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE [dbo].[gen_EmployeeTypeSelectByEmployeeTypePks]
(
	@xml ntext
)
AS

DECLARE @hDoc int
EXEC sp_xml_preparedocument @hDoc OUTPUT, @xml

SELECT
	[EMPLOYEE_TYPE].[employee_type_id],
	[EMPLOYEE_TYPE].[name],
	[EMPLOYEE_TYPE].[created_by],
	[EMPLOYEE_TYPE].[created_date],
	[EMPLOYEE_TYPE].[modified_by],
	[EMPLOYEE_TYPE].[modified_date],
	[EMPLOYEE_TYPE].[time_stamp]
FROM 
[EMPLOYEE_TYPE]
WHERE

	[EMPLOYEE_TYPE].[employee_type_id] IN (SELECT [employee_type_id] 
											FROM OpenXML(@hDoc, '//Item', 2) 
											WITH ([employee_type_id] [Char] (36) 'employee_type_id')) 


exec sp_xml_removeDocument @hDoc

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[gen_EmployeeTypeSelectByEmployeeTypeSinglePk]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	drop procedure [dbo].[gen_EmployeeTypeSelectByEmployeeTypeSinglePk]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE [dbo].[gen_EmployeeTypeSelectByEmployeeTypeSinglePk]
(
	@employee_type_id [Int]
)
AS

SELECT 
	[EMPLOYEE_TYPE].[employee_type_id],
	[EMPLOYEE_TYPE].[name],
	[EMPLOYEE_TYPE].[created_by],
	[EMPLOYEE_TYPE].[created_date],
	[EMPLOYEE_TYPE].[modified_by],
	[EMPLOYEE_TYPE].[modified_date],
	[EMPLOYEE_TYPE].[time_stamp]

FROM
[EMPLOYEE_TYPE]
WHERE 
[EMPLOYEE_TYPE].[employee_type_id] = @employee_type_id 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[gen_EmployeeTypeInsert]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	drop procedure [dbo].[gen_EmployeeTypeInsert]
GO

SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[gen_EmployeeTypeInsert]
(
	@employee_type_id [Int] = default,
	@name [VarChar] (100) = default,
	@created_date [DateTime],
	@created_by [Varchar] (50),
	@modified_by [Varchar] (50)

)
AS
SET NOCOUNT OFF;

if (@created_date IS NULL)
SET @created_date = GetDate()
IF (@employee_type_id < 0) SET @employee_type_id = NULL;
if ((@employee_type_id IS NULL))
BEGIN
INSERT INTO [EMPLOYEE_TYPE]
(
	[name],
	[created_date],
	[created_by],
	[modified_date],
	[modified_by]
)
VALUES
(
	@name,
	@created_date,
	@created_by,
	@created_date,
	@modified_by
);
END
ELSE
BEGIN
SET identity_insert [EMPLOYEE_TYPE] on
INSERT INTO [EMPLOYEE_TYPE]
(
	[employee_type_id],
	[name],
	[created_date],
	[created_by],
	[modified_date],
	[modified_by]
)
VALUES
(
	@employee_type_id,
	@name,
	@created_date,
	@created_by,
	@created_date,
	@modified_by
);
SET identity_insert [EMPLOYEE_TYPE] off
END


SELECT 
	[EMPLOYEE_TYPE].[employee_type_id],
	[EMPLOYEE_TYPE].[name],
	[EMPLOYEE_TYPE].[created_by],
	[EMPLOYEE_TYPE].[created_date],
	[EMPLOYEE_TYPE].[modified_by],
	[EMPLOYEE_TYPE].[modified_date],
	[EMPLOYEE_TYPE].[time_stamp]

FROM
[EMPLOYEE_TYPE]
WHERE
	[EMPLOYEE_TYPE].[employee_type_id] = SCOPE_IDENTITY();
GO

SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS ON
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[gen_EmployeeTypePagingSelect]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	drop procedure [dbo].[gen_EmployeeTypePagingSelect]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE [dbo].[gen_EmployeeTypePagingSelect]
(
	@page [Int], -- page number selected by the user
	@pageSize [Int], -- number of items on the page
	@orderByColumn [Varchar] (100), -- name of column to order things by
	@ascending [Bit], -- order column ascending or descending
	@filter [Varchar] (100) = null, -- filter statement passed in to determine like criteria on order by column
	@count [Int] out -- number of items in the collection
)
AS

SET NOCOUNT ON;

CREATE TABLE #tmpTable
(
	[employee_type_id] [Int]
)

DECLARE @total__ivqatedr int
DECLARE @orderByColumnIndex int
-- remove top x values from the temp table based upon the specific page requested
SET @total__ivqatedr = (@pageSize * @page)
IF (@total__ivqatedr <> 0)
BEGIN
	SET ROWCOUNT @total__ivqatedr
END
INSERT INTO #tmpTable
(
	[employee_type_id]
)
SELECT
	[EMPLOYEE_TYPE].[employee_type_id]
FROM
[EMPLOYEE_TYPE]
WHERE
	(@orderByColumn = 'employee_type_id' and (((@filter is null) or ([EMPLOYEE_TYPE].[employee_type_id] is null)) or (@filter is not null and [EMPLOYEE_TYPE].[employee_type_id] = @filter)))
or
	(@orderByColumn = 'name' and (((@filter is null) or ([EMPLOYEE_TYPE].[name] is null)) or (@filter is not null and [EMPLOYEE_TYPE].[name] LIKE @filter)))
ORDER BY
	CASE @ascending WHEN 0 THEN CASE @orderByColumn WHEN 'employee_type_id' THEN [EMPLOYEE_TYPE].[employee_type_id] END END DESC, 
	CASE @ascending WHEN 1 THEN CASE @orderByColumn WHEN 'employee_type_id' THEN [EMPLOYEE_TYPE].[employee_type_id] END END, 
	CASE @ascending WHEN 0 THEN CASE @orderByColumn WHEN 'name' THEN [EMPLOYEE_TYPE].[name] END END DESC, 
	CASE @ascending WHEN 1 THEN CASE @orderByColumn WHEN 'name' THEN [EMPLOYEE_TYPE].[name] END END

-- set @count based on the rows moved in the previous statement
SET ROWCOUNT 0
SET @count = (
SELECT count(*)
FROM
[EMPLOYEE_TYPE]
WHERE
	(@orderByColumn = 'employee_type_id' and (((@filter is null) or ([EMPLOYEE_TYPE].[employee_type_id] is null)) or (@filter is not null and [EMPLOYEE_TYPE].[employee_type_id] = @filter)))
or
	(@orderByColumn = 'name' and (((@filter is null) or ([EMPLOYEE_TYPE].[name] is null)) or (@filter is not null and [EMPLOYEE_TYPE].[name] LIKE @filter)))
)

-- remove top x values from the temp table based upon the specific page requested
SET @total__ivqatedr = (@pageSize * @page) - @pageSize
IF (@total__ivqatedr <> 0)
BEGIN
	SET ROWCOUNT @total__ivqatedr
	DELETE FROM #tmpTable
END

-- return the number of rows requested as the page size
SET ROWCOUNT @pageSize
SELECT
	[EMPLOYEE_TYPE].[employee_type_id],
	[EMPLOYEE_TYPE].[name],
	[EMPLOYEE_TYPE].[created_by],
	[EMPLOYEE_TYPE].[created_date],
	[EMPLOYEE_TYPE].[modified_by],
	[EMPLOYEE_TYPE].[modified_date],
	[EMPLOYEE_TYPE].[time_stamp]
FROM
	[#tmpTable]
	INNER JOIN [EMPLOYEE_TYPE] ON #tmpTable.[employee_type_id] = [EMPLOYEE_TYPE].[employee_type_id]
ORDER BY
	CASE @ascending WHEN 0 THEN CASE @orderByColumn WHEN 'employee_type_id' THEN [EMPLOYEE_TYPE].[employee_type_id] END END DESC, 
	CASE @ascending WHEN 1 THEN CASE @orderByColumn WHEN 'employee_type_id' THEN [EMPLOYEE_TYPE].[employee_type_id] END END, 
	CASE @ascending WHEN 0 THEN CASE @orderByColumn WHEN 'name' THEN [EMPLOYEE_TYPE].[name] END END DESC, 
	CASE @ascending WHEN 1 THEN CASE @orderByColumn WHEN 'name' THEN [EMPLOYEE_TYPE].[name] END END

DROP TABLE #tmpTable

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[gen_EmployeeTypeSelectByCreatedDateRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	drop procedure [dbo].[gen_EmployeeTypeSelectByCreatedDateRange]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE [dbo].[gen_EmployeeTypeSelectByCreatedDateRange]
(
	@start_date [DateTime],
	@end_date [DateTime]
)
AS

SET NOCOUNT ON;

SELECT
	[EMPLOYEE_TYPE].[employee_type_id],
	[EMPLOYEE_TYPE].[name],
	[EMPLOYEE_TYPE].[created_by],
	[EMPLOYEE_TYPE].[created_date],
	[EMPLOYEE_TYPE].[modified_by],
	[EMPLOYEE_TYPE].[modified_date],
	[EMPLOYEE_TYPE].[time_stamp]
FROM
[EMPLOYEE_TYPE]
WHERE
((([EMPLOYEE_TYPE].[created_date] IS NULL) AND (@start_date IS NULL)) OR (@start_date <= [EMPLOYEE_TYPE].[created_date])) AND 
((([EMPLOYEE_TYPE].[created_date] IS NULL) AND (@end_date IS NULL)) OR (@end_date >= [EMPLOYEE_TYPE].[created_date]))
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[gen_EmployeeTypeSelectByModifiedDateRange]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	drop procedure [dbo].[gen_EmployeeTypeSelectByModifiedDateRange]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE [dbo].[gen_EmployeeTypeSelectByModifiedDateRange]
(
	@start_date [DateTime],
	@end_date [DateTime]
)
AS

SET NOCOUNT ON;

SELECT
	[EMPLOYEE_TYPE].[employee_type_id],
	[EMPLOYEE_TYPE].[name],
	[EMPLOYEE_TYPE].[created_by],
	[EMPLOYEE_TYPE].[created_date],
	[EMPLOYEE_TYPE].[modified_by],
	[EMPLOYEE_TYPE].[modified_date],
	[EMPLOYEE_TYPE].[time_stamp]
FROM
[EMPLOYEE_TYPE]
WHERE
((([EMPLOYEE_TYPE].[modified_date] IS NULL) AND (@start_date IS NULL)) OR (@start_date <= [EMPLOYEE_TYPE].[modified_date])) AND 
((([EMPLOYEE_TYPE].[modified_date] IS NULL) AND (@end_date IS NULL)) OR (@end_date >= [EMPLOYEE_TYPE].[modified_date]))
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[gen_EmployeeTypeSelect]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	drop procedure [dbo].[gen_EmployeeTypeSelect]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE [dbo].[gen_EmployeeTypeSelect]
AS

SET NOCOUNT ON;

SELECT
	[EMPLOYEE_TYPE].[employee_type_id],
	[EMPLOYEE_TYPE].[name],
	[EMPLOYEE_TYPE].[created_by],
	[EMPLOYEE_TYPE].[created_date],
	[EMPLOYEE_TYPE].[modified_by],
	[EMPLOYEE_TYPE].[modified_date],
	[EMPLOYEE_TYPE].[time_stamp]
FROM 
[EMPLOYEE_TYPE]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

